import {
  users, content, campaigns, analytics, integrations, aiModels, schedules,
  type User, type InsertUser,
  type Content, type InsertContent,
  type Campaign, type InsertCampaign,
  type Analytics, type InsertAnalytics,
  type Integration, type InsertIntegration,
  type AIModel,
  type Schedule, type InsertSchedule
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Content operations
  getContent(id: number): Promise<Content | undefined>;
  getContentByUserId(userId: number): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
  updateContent(id: number, updates: Partial<Content>): Promise<Content | undefined>;
  deleteContent(id: number): Promise<boolean>;
  getContentByStatus(userId: number, status: string): Promise<Content[]>;

  // Campaign operations
  getCampaign(id: number): Promise<Campaign | undefined>;
  getCampaignsByUserId(userId: number): Promise<Campaign[]>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, updates: Partial<Campaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: number): Promise<boolean>;

  // Analytics operations
  getAnalytics(userId: number, filters?: { contentId?: number; platform?: string; startDate?: Date; endDate?: Date }): Promise<Analytics[]>;
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
  getAnalyticsSummary(userId: number): Promise<{
    totalViews: number;
    totalClicks: number;
    totalRevenue: number;
    engagementRate: number;
    conversionRate: number;
  }>;

  // Integration operations
  getIntegration(userId: number, platform: string): Promise<Integration | undefined>;
  getIntegrationsByUserId(userId: number): Promise<Integration[]>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, updates: Partial<Integration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<boolean>;

  // AI Model operations
  getAIModels(): Promise<AIModel[]>;
  getAIModel(id: number): Promise<AIModel | undefined>;
  updateAIModelStats(id: number, stats: { successRate?: number; qualityScore?: number }): Promise<void>;

  // Schedule operations
  getSchedules(userId: number): Promise<Schedule[]>;
  getSchedulesByStatus(status: string): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, updates: Partial<Schedule>): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private content: Map<number, Content>;
  private campaigns: Map<number, Campaign>;
  private analytics: Map<number, Analytics>;
  private integrations: Map<number, Integration>;
  private aiModels: Map<number, AIModel>;
  private schedules: Map<number, Schedule>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.content = new Map();
    this.campaigns = new Map();
    this.analytics = new Map();
    this.integrations = new Map();
    this.aiModels = new Map();
    this.schedules = new Map();
    this.currentId = 1;

    // Initialize default AI models
    this.initializeAIModels();
  }

  private initializeAIModels() {
    const models: Omit<AIModel, 'id'>[] = [
      { name: "GPT-4", provider: "openai", model: "gpt-4", isActive: true, successRate: "96.0", qualityScore: "9.2", costPerRequest: "0.03" },
      { name: "Claude", provider: "anthropic", model: "claude-3-sonnet", isActive: true, successRate: "94.0", qualityScore: "8.9", costPerRequest: "0.015" },
      { name: "Gemini", provider: "google", model: "gemini-pro", isActive: true, successRate: "92.0", qualityScore: "8.7", costPerRequest: "0.001" }
    ];

    models.forEach(model => {
      const id = this.currentId++;
      this.aiModels.set(id, { ...model, id });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Content operations
  async getContent(id: number): Promise<Content | undefined> {
    return this.content.get(id);
  }

  async getContentByUserId(userId: number): Promise<Content[]> {
    return Array.from(this.content.values()).filter(content => content.userId === userId);
  }

  async createContent(insertContent: InsertContent): Promise<Content> {
    const id = this.currentId++;
    const content: Content = { 
      ...insertContent, 
      id, 
      createdAt: new Date(),
      publishedAt: null
    };
    this.content.set(id, content);
    return content;
  }

  async updateContent(id: number, updates: Partial<Content>): Promise<Content | undefined> {
    const content = this.content.get(id);
    if (!content) return undefined;
    
    const updatedContent = { ...content, ...updates };
    if (updates.status === 'published' && !content.publishedAt) {
      updatedContent.publishedAt = new Date();
    }
    this.content.set(id, updatedContent);
    return updatedContent;
  }

  async deleteContent(id: number): Promise<boolean> {
    return this.content.delete(id);
  }

  async getContentByStatus(userId: number, status: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(
      content => content.userId === userId && content.status === status
    );
  }

  // Campaign operations
  async getCampaign(id: number): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async getCampaignsByUserId(userId: number): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).filter(campaign => campaign.userId === userId);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.currentId++;
    const campaign: Campaign = { 
      ...insertCampaign, 
      id, 
      createdAt: new Date() 
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: number, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const campaign = this.campaigns.get(id);
    if (!campaign) return undefined;
    
    const updatedCampaign = { ...campaign, ...updates };
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    return this.campaigns.delete(id);
  }

  // Analytics operations
  async getAnalytics(userId: number, filters?: { contentId?: number; platform?: string; startDate?: Date; endDate?: Date }): Promise<Analytics[]> {
    let result = Array.from(this.analytics.values()).filter(analytics => analytics.userId === userId);
    
    if (filters?.contentId) {
      result = result.filter(a => a.contentId === filters.contentId);
    }
    if (filters?.platform) {
      result = result.filter(a => a.platform === filters.platform);
    }
    if (filters?.startDate) {
      result = result.filter(a => a.date >= filters.startDate!);
    }
    if (filters?.endDate) {
      result = result.filter(a => a.date <= filters.endDate!);
    }
    
    return result;
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const id = this.currentId++;
    const analytics: Analytics = { 
      ...insertAnalytics, 
      id, 
      date: new Date() 
    };
    this.analytics.set(id, analytics);
    return analytics;
  }

  async getAnalyticsSummary(userId: number): Promise<{
    totalViews: number;
    totalClicks: number;
    totalRevenue: number;
    engagementRate: number;
    conversionRate: number;
  }> {
    const userAnalytics = Array.from(this.analytics.values()).filter(a => a.userId === userId);
    
    const totalViews = userAnalytics.reduce((sum, a) => sum + (a.views || 0), 0);
    const totalClicks = userAnalytics.reduce((sum, a) => sum + (a.clicks || 0), 0);
    const totalRevenue = userAnalytics.reduce((sum, a) => sum + parseFloat(a.revenue || "0"), 0);
    const totalEngagements = userAnalytics.reduce((sum, a) => sum + (a.likes || 0) + (a.shares || 0) + (a.comments || 0), 0);
    const totalConversions = userAnalytics.reduce((sum, a) => sum + (a.conversions || 0), 0);
    
    const engagementRate = totalViews > 0 ? (totalEngagements / totalViews) * 100 : 0;
    const conversionRate = totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0;
    
    return {
      totalViews,
      totalClicks,
      totalRevenue,
      engagementRate,
      conversionRate
    };
  }

  // Integration operations
  async getIntegration(userId: number, platform: string): Promise<Integration | undefined> {
    return Array.from(this.integrations.values()).find(
      integration => integration.userId === userId && integration.platform === platform
    );
  }

  async getIntegrationsByUserId(userId: number): Promise<Integration[]> {
    return Array.from(this.integrations.values()).filter(integration => integration.userId === userId);
  }

  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const id = this.currentId++;
    const integration: Integration = { 
      ...insertIntegration, 
      id, 
      createdAt: new Date() 
    };
    this.integrations.set(id, integration);
    return integration;
  }

  async updateIntegration(id: number, updates: Partial<Integration>): Promise<Integration | undefined> {
    const integration = this.integrations.get(id);
    if (!integration) return undefined;
    
    const updatedIntegration = { ...integration, ...updates };
    this.integrations.set(id, updatedIntegration);
    return updatedIntegration;
  }

  async deleteIntegration(id: number): Promise<boolean> {
    return this.integrations.delete(id);
  }

  // AI Model operations
  async getAIModels(): Promise<AIModel[]> {
    return Array.from(this.aiModels.values());
  }

  async getAIModel(id: number): Promise<AIModel | undefined> {
    return this.aiModels.get(id);
  }

  async updateAIModelStats(id: number, stats: { successRate?: number; qualityScore?: number }): Promise<void> {
    const model = this.aiModels.get(id);
    if (model) {
      if (stats.successRate !== undefined) {
        model.successRate = stats.successRate.toString();
      }
      if (stats.qualityScore !== undefined) {
        model.qualityScore = stats.qualityScore.toString();
      }
      this.aiModels.set(id, model);
    }
  }

  // Schedule operations
  async getSchedules(userId: number): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(schedule => schedule.userId === userId);
  }

  async getSchedulesByStatus(status: string): Promise<Schedule[]> {
    return Array.from(this.schedules.values()).filter(schedule => schedule.status === status);
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const id = this.currentId++;
    const schedule: Schedule = { 
      ...insertSchedule, 
      id, 
      createdAt: new Date() 
    };
    this.schedules.set(id, schedule);
    return schedule;
  }

  async updateSchedule(id: number, updates: Partial<Schedule>): Promise<Schedule | undefined> {
    const schedule = this.schedules.get(id);
    if (!schedule) return undefined;
    
    const updatedSchedule = { ...schedule, ...updates };
    this.schedules.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    return this.schedules.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  // Content operations
  async getContent(id: number): Promise<Content | undefined> {
    const [contentItem] = await db.select().from(content).where(eq(content.id, id));
    return contentItem || undefined;
  }

  async getContentByUserId(userId: number): Promise<Content[]> {
    return await db.select().from(content).where(eq(content.userId, userId)).orderBy(desc(content.createdAt));
  }

  async createContent(insertContent: InsertContent): Promise<Content> {
    const [contentItem] = await db.insert(content).values(insertContent).returning();
    return contentItem;
  }

  async updateContent(id: number, updates: Partial<Content>): Promise<Content | undefined> {
    const [contentItem] = await db.update(content).set(updates).where(eq(content.id, id)).returning();
    return contentItem;
  }

  async deleteContent(id: number): Promise<boolean> {
    const result = await db.delete(content).where(eq(content.id, id));
    return result.rowCount > 0;
  }

  async getContentByStatus(userId: number, status: string): Promise<Content[]> {
    return await db.select().from(content)
      .where(and(eq(content.userId, userId), eq(content.status, status)))
      .orderBy(desc(content.createdAt));
  }

  // Campaign operations
  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async getCampaignsByUserId(userId: number): Promise<Campaign[]> {
    return await db.select().from(campaigns).where(eq(campaigns.userId, userId)).orderBy(desc(campaigns.createdAt));
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const [campaign] = await db.insert(campaigns).values(insertCampaign).returning();
    return campaign;
  }

  async updateCampaign(id: number, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    const [campaign] = await db.update(campaigns).set(updates).where(eq(campaigns.id, id)).returning();
    return campaign;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    const result = await db.delete(campaigns).where(eq(campaigns.id, id));
    return result.rowCount > 0;
  }

  // Analytics operations
  async getAnalytics(userId: number, filters?: { contentId?: number; platform?: string; startDate?: Date; endDate?: Date }): Promise<Analytics[]> {
    let query = db.select().from(analytics).where(eq(analytics.userId, userId));
    
    if (filters) {
      const conditions = [eq(analytics.userId, userId)];
      if (filters.contentId) conditions.push(eq(analytics.contentId, filters.contentId));
      if (filters.platform) conditions.push(eq(analytics.platform, filters.platform));
      if (filters.startDate) conditions.push(gte(analytics.date, filters.startDate));
      if (filters.endDate) conditions.push(lte(analytics.date, filters.endDate));
      query = db.select().from(analytics).where(and(...conditions));
    }
    
    return await query.orderBy(desc(analytics.date));
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const [analytic] = await db.insert(analytics).values(insertAnalytics).returning();
    return analytic;
  }

  async getAnalyticsSummary(userId: number): Promise<{
    totalViews: number;
    totalClicks: number;
    totalRevenue: number;
    engagementRate: number;
    conversionRate: number;
  }> {
    const results = await db.select({
      totalViews: sql<number>`COALESCE(SUM(${analytics.views}), 0)`,
      totalClicks: sql<number>`COALESCE(SUM(${analytics.clicks}), 0)`,
      totalRevenue: sql<number>`COALESCE(SUM(CAST(${analytics.revenue} AS DECIMAL)), 0)`,
      totalConversions: sql<number>`COALESCE(SUM(${analytics.conversions}), 0)`
    }).from(analytics).where(eq(analytics.userId, userId));

    const summary = results[0] || { totalViews: 0, totalClicks: 0, totalRevenue: 0, totalConversions: 0 };
    const engagementRate = summary.totalViews > 0 ? (summary.totalClicks / summary.totalViews) * 100 : 0;
    const conversionRate = summary.totalClicks > 0 ? (summary.totalConversions / summary.totalClicks) * 100 : 0;

    return {
      totalViews: Number(summary.totalViews),
      totalClicks: Number(summary.totalClicks),
      totalRevenue: Number(summary.totalRevenue),
      engagementRate: Math.round(engagementRate * 10) / 10,
      conversionRate: Math.round(conversionRate * 10) / 10
    };
  }

  // Integration operations
  async getIntegration(userId: number, platform: string): Promise<Integration | undefined> {
    const [integration] = await db.select().from(integrations)
      .where(and(eq(integrations.userId, userId), eq(integrations.platform, platform)));
    return integration || undefined;
  }

  async getIntegrationsByUserId(userId: number): Promise<Integration[]> {
    return await db.select().from(integrations).where(eq(integrations.userId, userId));
  }

  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const [integration] = await db.insert(integrations).values(insertIntegration).returning();
    return integration;
  }

  async updateIntegration(id: number, updates: Partial<Integration>): Promise<Integration | undefined> {
    const [integration] = await db.update(integrations).set(updates).where(eq(integrations.id, id)).returning();
    return integration;
  }

  async deleteIntegration(id: number): Promise<boolean> {
    const result = await db.delete(integrations).where(eq(integrations.id, id));
    return result.rowCount > 0;
  }

  // AI Model operations
  async getAIModels(): Promise<AIModel[]> {
    const models = await db.select().from(aiModels);
    
    // Initialize default AI models if none exist
    if (models.length === 0) {
      const defaultModels = [
        { name: "GPT-4", provider: "openai", model: "gpt-4", isActive: true, successRate: "96.0", qualityScore: "9.2", costPerRequest: "0.03" },
        { name: "Claude", provider: "anthropic", model: "claude-3-sonnet", isActive: true, successRate: "94.0", qualityScore: "8.9", costPerRequest: "0.015" },
        { name: "Gemini", provider: "google", model: "gemini-pro", isActive: true, successRate: "92.0", qualityScore: "8.7", costPerRequest: "0.001" }
      ];
      
      for (const model of defaultModels) {
        await db.insert(aiModels).values(model);
      }
      
      return await db.select().from(aiModels);
    }
    
    return models;
  }

  async getAIModel(id: number): Promise<AIModel | undefined> {
    const [model] = await db.select().from(aiModels).where(eq(aiModels.id, id));
    return model || undefined;
  }

  async updateAIModelStats(id: number, stats: { successRate?: number; qualityScore?: number }): Promise<void> {
    const updates: any = {};
    if (stats.successRate !== undefined) updates.successRate = stats.successRate.toString();
    if (stats.qualityScore !== undefined) updates.qualityScore = stats.qualityScore.toString();
    
    await db.update(aiModels).set(updates).where(eq(aiModels.id, id));
  }

  // Schedule operations
  async getSchedules(userId: number): Promise<Schedule[]> {
    return await db.select().from(schedules).where(eq(schedules.userId, userId)).orderBy(schedules.scheduledFor);
  }

  async getSchedulesByStatus(status: string): Promise<Schedule[]> {
    return await db.select().from(schedules).where(eq(schedules.status, status)).orderBy(schedules.scheduledFor);
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const [schedule] = await db.insert(schedules).values(insertSchedule).returning();
    return schedule;
  }

  async updateSchedule(id: number, updates: Partial<Schedule>): Promise<Schedule | undefined> {
    const [schedule] = await db.update(schedules).set(updates).where(eq(schedules.id, id)).returning();
    return schedule;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    const result = await db.delete(schedules).where(eq(schedules.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
