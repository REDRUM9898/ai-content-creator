import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiService } from "./services/ai";
import { publishingService } from "./services/publishers";
import { analyticsService } from "./services/analytics";
import { insertContentSchema, insertCampaignSchema, insertIntegrationSchema, insertScheduleSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  const MemoryStoreSession = MemoryStore(session);
  
  app.use(session({
    secret: process.env.SESSION_SECRET || 'ai-content-empire-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
    }
  }));

  // Authentication middleware
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.session && req.session.authenticated) {
      return next();
    }
    res.status(401).json({ error: "Unauthorized" });
  };

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    const { password } = req.body;
    
    // Check if the password matches RUMRED
    if (password === "RUMRED") {
      (req.session as any).authenticated = true;
      (req.session as any).userId = 1; // Default user
      res.json({ success: true, message: "Authenticated successfully" });
    } else {
      res.status(401).json({ error: "Invalid password" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/check", (req, res) => {
    res.json({ authenticated: !!(req.session && (req.session as any).authenticated) });
  });
  // Content routes
  app.get("/api/content", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const content = await storage.getContentByUserId(userId);
      res.json(content);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch content" });
    }
  });

  app.post("/api/content", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const validatedData = insertContentSchema.parse({ ...req.body, userId });
      const content = await storage.createContent(validatedData);
      res.json(content);
    } catch (error) {
      res.status(400).json({ error: "Invalid content data" });
    }
  });

  app.put("/api/content/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const content = await storage.updateContent(id, updates);
      if (!content) {
        return res.status(404).json({ error: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(400).json({ error: "Failed to update content" });
    }
  });

  app.delete("/api/content/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteContent(id);
      if (!success) {
        return res.status(404).json({ error: "Content not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete content" });
    }
  });

  // AI Content Generation
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, contentType, keywords, tone, length, targetAudience, model = 'gpt-4' } = req.body;
      
      if (!prompt || !contentType) {
        return res.status(400).json({ error: "Prompt and content type are required" });
      }

      const result = await aiService.generateContent({
        prompt,
        contentType,
        keywords,
        tone,
        length,
        targetAudience
      }, model);

      // Save generated content
      const userId = 1; // TODO: Get from session/auth
      const content = await storage.createContent({
        userId,
        title: result.title,
        body: result.content,
        type: contentType,
        status: 'generated',
        aiModel: model,
        keywords: keywords || [],
        platforms: [],
        metadata: {
          seoScore: result.seoScore,
          readabilityScore: result.readabilityScore
        }
      });

      res.json({ ...result, contentId: content.id });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to generate content" });
    }
  });

  app.post("/api/ai/optimize-seo", async (req, res) => {
    try {
      const { content, keywords } = req.body;
      
      if (!content || !keywords?.length) {
        return res.status(400).json({ error: "Content and keywords are required" });
      }

      const result = await aiService.optimizeForSEO(content, keywords);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to optimize content for SEO" });
    }
  });

  // Publishing routes
  app.post("/api/publish", async (req, res) => {
    try {
      const { contentId, platforms, scheduleFor } = req.body;
      const userId = 1; // TODO: Get from session/auth
      
      const content = await storage.getContent(contentId);
      if (!content || content.userId !== userId) {
        return res.status(404).json({ error: "Content not found" });
      }

      const integrations = await storage.getIntegrationsByUserId(userId);
      const configs = platforms.map((platform: string) => {
        const integration = integrations.find(i => i.platform === platform);
        if (!integration) return null;
        return {
          platform,
          accessToken: integration.accessToken!,
          refreshToken: integration.refreshToken,
          config: integration.config
        };
      }).filter(Boolean);

      if (scheduleFor) {
        // Schedule for later
        for (const platform of platforms) {
          await storage.createSchedule({
            userId,
            contentId,
            platform,
            scheduledFor: new Date(scheduleFor),
            status: 'pending',
            attempts: 0,
            lastError: null
          });
        }
        res.json({ success: true, scheduled: true });
      } else {
        // Publish immediately
        const results = await publishingService.publishContent({
          content: content.body,
          title: content.title,
          platforms,
          metadata: content.metadata
        }, configs);

        // Update content status
        await storage.updateContent(contentId, { status: 'published' });

        res.json({ success: true, results });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to publish content" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/metrics", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const metrics = await analyticsService.getUserMetrics(userId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics metrics" });
    }
  });

  app.get("/api/analytics/report", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const end = endDate ? new Date(endDate as string) : new Date();
      
      const report = await analyticsService.generateAnalyticsReport(userId, start, end);
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate analytics report" });
    }
  });

  app.post("/api/analytics/track", async (req, res) => {
    try {
      const { contentId, platform, type, revenue } = req.body;
      const userId = 1; // TODO: Get from session/auth
      
      if (type === 'view') {
        await analyticsService.trackContentView(contentId, platform, userId);
      } else {
        await analyticsService.trackContentEngagement(contentId, platform, userId, type, revenue);
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to track analytics" });
    }
  });

  // Campaign routes
  app.get("/api/campaigns", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const campaigns = await storage.getCampaignsByUserId(userId);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/campaigns", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const validatedData = insertCampaignSchema.parse({ ...req.body, userId });
      const campaign = await storage.createCampaign(validatedData);
      res.json(campaign);
    } catch (error) {
      res.status(400).json({ error: "Invalid campaign data" });
    }
  });

  // Integration routes
  app.get("/api/integrations", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const integrations = await storage.getIntegrationsByUserId(userId);
      res.json(integrations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch integrations" });
    }
  });

  app.post("/api/integrations", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const validatedData = insertIntegrationSchema.parse({ ...req.body, userId });
      const integration = await storage.createIntegration(validatedData);
      res.json(integration);
    } catch (error) {
      res.status(400).json({ error: "Invalid integration data" });
    }
  });

  app.delete("/api/integrations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteIntegration(id);
      if (!success) {
        return res.status(404).json({ error: "Integration not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete integration" });
    }
  });

  // AI Models routes
  app.get("/api/ai/models", async (req, res) => {
    try {
      const models = await storage.getAIModels();
      res.json(models);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI models" });
    }
  });

  // Schedule routes
  app.get("/api/schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const schedules = await storage.getSchedules(userId);
      res.json(schedules);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch schedules" });
    }
  });

  app.post("/api/schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from session/auth
      const validatedData = insertScheduleSchema.parse({ ...req.body, userId });
      const schedule = await storage.createSchedule(validatedData);
      res.json(schedule);
    } catch (error) {
      res.status(400).json({ error: "Invalid schedule data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
