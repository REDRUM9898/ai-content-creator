import { storage } from '../storage';

export interface AnalyticsMetrics {
  totalRevenue: number;
  monthlyRevenue: number;
  contentGenerated: number;
  totalViews: number;
  engagementRate: number;
  conversionRate: number;
  aiEfficiency: number;
  seoScore: number;
  platformPerformance: Array<{
    platform: string;
    views: number;
    engagement: number;
    revenue: number;
  }>;
  contentPerformance: Array<{
    contentId: number;
    title: string;
    views: number;
    engagement: number;
    revenue: number;
    platform: string;
  }>;
  revenueHistory: Array<{
    date: string;
    revenue: number;
    views: number;
    conversions: number;
  }>;
}

export class AnalyticsService {
  async getUserMetrics(userId: number): Promise<AnalyticsMetrics> {
    const userContent = await storage.getContentByUserId(userId);
    const userAnalytics = await storage.getAnalytics(userId);
    const aiModels = await storage.getAIModels();

    // Calculate total revenue
    const totalRevenue = userAnalytics.reduce((sum, analytics) => {
      return sum + parseFloat(analytics.revenue || "0");
    }, 0);

    // Calculate monthly revenue (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const monthlyAnalytics = userAnalytics.filter(a => a.date >= thirtyDaysAgo);
    const monthlyRevenue = monthlyAnalytics.reduce((sum, analytics) => {
      return sum + parseFloat(analytics.revenue || "0");
    }, 0);

    // Content generated count
    const contentGenerated = userContent.length;

    // Total views
    const totalViews = userAnalytics.reduce((sum, analytics) => {
      return sum + (analytics.views || 0);
    }, 0);

    // Engagement rate calculation
    const totalEngagements = userAnalytics.reduce((sum, analytics) => {
      return sum + (analytics.likes || 0) + (analytics.shares || 0) + (analytics.comments || 0);
    }, 0);
    const engagementRate = totalViews > 0 ? (totalEngagements / totalViews) * 100 : 0;

    // Conversion rate calculation
    const totalClicks = userAnalytics.reduce((sum, analytics) => {
      return sum + (analytics.clicks || 0);
    }, 0);
    const totalConversions = userAnalytics.reduce((sum, analytics) => {
      return sum + (analytics.conversions || 0);
    }, 0);
    const conversionRate = totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0;

    // AI efficiency (average success rate of all models)
    const aiEfficiency = aiModels.reduce((sum, model) => {
      return sum + parseFloat(model.successRate || "0");
    }, 0) / aiModels.length;

    // SEO score (average of all content)
    const contentWithSEO = userContent.filter(c => c.metadata?.seoScore);
    const avgSeoScore = contentWithSEO.length > 0 
      ? contentWithSEO.reduce((sum, content) => sum + (content.metadata?.seoScore || 0), 0) / contentWithSEO.length
      : 85; // Default score

    // Platform performance
    const platformPerformance = this.calculatePlatformPerformance(userAnalytics);

    // Content performance
    const contentPerformance = this.calculateContentPerformance(userContent, userAnalytics);

    // Revenue history (last 30 days)
    const revenueHistory = this.calculateRevenueHistory(userAnalytics, 30);

    return {
      totalRevenue,
      monthlyRevenue,
      contentGenerated,
      totalViews,
      engagementRate,
      conversionRate,
      aiEfficiency,
      seoScore: avgSeoScore,
      platformPerformance,
      contentPerformance,
      revenueHistory
    };
  }

  private calculatePlatformPerformance(analytics: any[]): Array<{
    platform: string;
    views: number;
    engagement: number;
    revenue: number;
  }> {
    const platformMap = new Map<string, { views: number; engagement: number; revenue: number }>();

    analytics.forEach(analytics => {
      const platform = analytics.platform;
      if (!platformMap.has(platform)) {
        platformMap.set(platform, { views: 0, engagement: 0, revenue: 0 });
      }

      const current = platformMap.get(platform)!;
      current.views += analytics.views || 0;
      current.engagement += (analytics.likes || 0) + (analytics.shares || 0) + (analytics.comments || 0);
      current.revenue += parseFloat(analytics.revenue || "0");
    });

    return Array.from(platformMap.entries()).map(([platform, data]) => ({
      platform,
      ...data
    }));
  }

  private calculateContentPerformance(content: any[], analytics: any[]): Array<{
    contentId: number;
    title: string;
    views: number;
    engagement: number;
    revenue: number;
    platform: string;
  }> {
    const contentPerformance: any[] = [];

    content.forEach(contentItem => {
      const contentAnalytics = analytics.filter(a => a.contentId === contentItem.id);
      
      contentAnalytics.forEach(analytics => {
        contentPerformance.push({
          contentId: contentItem.id,
          title: contentItem.title,
          views: analytics.views || 0,
          engagement: (analytics.likes || 0) + (analytics.shares || 0) + (analytics.comments || 0),
          revenue: parseFloat(analytics.revenue || "0"),
          platform: analytics.platform
        });
      });
    });

    return contentPerformance.sort((a, b) => b.views - a.views).slice(0, 10); // Top 10
  }

  private calculateRevenueHistory(analytics: any[], days: number): Array<{
    date: string;
    revenue: number;
    views: number;
    conversions: number;
  }> {
    const history: Map<string, { revenue: number; views: number; conversions: number }> = new Map();

    // Initialize last N days
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      history.set(dateStr, { revenue: 0, views: 0, conversions: 0 });
    }

    // Aggregate analytics by date
    analytics.forEach(analytics => {
      const dateStr = analytics.date.toISOString().split('T')[0];
      if (history.has(dateStr)) {
        const current = history.get(dateStr)!;
        current.revenue += parseFloat(analytics.revenue || "0");
        current.views += analytics.views || 0;
        current.conversions += analytics.conversions || 0;
      }
    });

    return Array.from(history.entries()).map(([date, data]) => ({
      date,
      ...data
    })).sort((a, b) => a.date.localeCompare(b.date));
  }

  async trackContentView(contentId: number, platform: string, userId: number): Promise<void> {
    await storage.createAnalytics({
      userId,
      contentId,
      platform,
      views: 1,
      clicks: 0,
      shares: 0,
      likes: 0,
      comments: 0,
      conversions: 0,
      revenue: "0"
    });
  }

  async trackContentEngagement(
    contentId: number, 
    platform: string, 
    userId: number, 
    type: 'click' | 'share' | 'like' | 'comment' | 'conversion',
    revenue?: number
  ): Promise<void> {
    const analyticsData: any = {
      userId,
      contentId,
      platform,
      views: 0,
      clicks: 0,
      shares: 0,
      likes: 0,
      comments: 0,
      conversions: 0,
      revenue: revenue?.toString() || "0"
    };

    analyticsData[type === 'click' ? 'clicks' : type + 's'] = 1;

    await storage.createAnalytics(analyticsData);
  }

  async generateAnalyticsReport(userId: number, startDate: Date, endDate: Date): Promise<{
    summary: AnalyticsMetrics;
    trends: {
      revenueGrowth: number;
      viewsGrowth: number;
      engagementGrowth: number;
    };
    recommendations: string[];
  }> {
    const metrics = await this.getUserMetrics(userId);
    
    // Get comparison period (same duration before start date)
    const durationMs = endDate.getTime() - startDate.getTime();
    const comparisonStart = new Date(startDate.getTime() - durationMs);
    const comparisonEnd = startDate;

    const currentPeriodAnalytics = await storage.getAnalytics(userId, { startDate, endDate });
    const comparisonPeriodAnalytics = await storage.getAnalytics(userId, { 
      startDate: comparisonStart, 
      endDate: comparisonEnd 
    });

    const currentRevenue = currentPeriodAnalytics.reduce((sum, a) => sum + parseFloat(a.revenue || "0"), 0);
    const comparisonRevenue = comparisonPeriodAnalytics.reduce((sum, a) => sum + parseFloat(a.revenue || "0"), 0);
    const revenueGrowth = comparisonRevenue > 0 ? ((currentRevenue - comparisonRevenue) / comparisonRevenue) * 100 : 0;

    const currentViews = currentPeriodAnalytics.reduce((sum, a) => sum + (a.views || 0), 0);
    const comparisonViews = comparisonPeriodAnalytics.reduce((sum, a) => sum + (a.views || 0), 0);
    const viewsGrowth = comparisonViews > 0 ? ((currentViews - comparisonViews) / comparisonViews) * 100 : 0;

    const currentEngagements = currentPeriodAnalytics.reduce((sum, a) => 
      sum + (a.likes || 0) + (a.shares || 0) + (a.comments || 0), 0);
    const comparisonEngagements = comparisonPeriodAnalytics.reduce((sum, a) => 
      sum + (a.likes || 0) + (a.shares || 0) + (a.comments || 0), 0);
    const engagementGrowth = comparisonEngagements > 0 ? ((currentEngagements - comparisonEngagements) / comparisonEngagements) * 100 : 0;

    const recommendations = this.generateRecommendations(metrics);

    return {
      summary: metrics,
      trends: {
        revenueGrowth,
        viewsGrowth,
        engagementGrowth
      },
      recommendations
    };
  }

  private generateRecommendations(metrics: AnalyticsMetrics): string[] {
    const recommendations: string[] = [];

    if (metrics.engagementRate < 5) {
      recommendations.push("Consider improving content engagement by adding more interactive elements and calls-to-action");
    }

    if (metrics.conversionRate < 2) {
      recommendations.push("Focus on optimizing your conversion funnel and improving call-to-action placement");
    }

    if (metrics.seoScore < 80) {
      recommendations.push("Enhance your SEO strategy by improving keyword optimization and content structure");
    }

    // Platform-specific recommendations
    const topPlatform = metrics.platformPerformance.sort((a, b) => b.revenue - a.revenue)[0];
    if (topPlatform) {
      recommendations.push(`${topPlatform.platform} is your top-performing platform. Consider increasing content frequency there`);
    }

    if (metrics.aiEfficiency < 90) {
      recommendations.push("Experiment with different AI models and prompts to improve content generation efficiency");
    }

    return recommendations;
  }
}

export const analyticsService = new AnalyticsService();
