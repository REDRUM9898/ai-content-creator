export interface PublishingConfig {
  platform: string;
  accessToken: string;
  refreshToken?: string;
  config?: Record<string, any>;
}

export interface PublishRequest {
  content: string;
  title: string;
  platforms: string[];
  scheduleFor?: Date;
  metadata?: Record<string, any>;
}

export interface PublishResponse {
  platform: string;
  success: boolean;
  postId?: string;
  url?: string;
  error?: string;
}

export class PublishingService {
  async publishContent(request: PublishRequest, configs: PublishingConfig[]): Promise<PublishResponse[]> {
    const results: PublishResponse[] = [];

    for (const platform of request.platforms) {
      const config = configs.find(c => c.platform === platform);
      if (!config) {
        results.push({
          platform,
          success: false,
          error: `No configuration found for platform: ${platform}`
        });
        continue;
      }

      try {
        const result = await this.publishToPlatform(platform, request, config);
        results.push(result);
      } catch (error) {
        results.push({
          platform,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return results;
  }

  private async publishToPlatform(
    platform: string,
    request: PublishRequest,
    config: PublishingConfig
  ): Promise<PublishResponse> {
    switch (platform.toLowerCase()) {
      case 'linkedin':
        return await this.publishToLinkedIn(request, config);
      case 'twitter':
        return await this.publishToTwitter(request, config);
      case 'medium':
        return await this.publishToMedium(request, config);
      case 'wordpress':
        return await this.publishToWordPress(request, config);
      case 'facebook':
        return await this.publishToFacebook(request, config);
      case 'instagram':
        return await this.publishToInstagram(request, config);
      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }
  }

  private async publishToLinkedIn(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      const response = await fetch('https://api.linkedin.com/v2/ugcPosts', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.accessToken}`,
          'Content-Type': 'application/json',
          'X-Restli-Protocol-Version': '2.0.0'
        },
        body: JSON.stringify({
          author: config.config?.authorId || `urn:li:person:${config.config?.personId}`,
          lifecycleState: 'PUBLISHED',
          specificContent: {
            'com.linkedin.ugc.ShareContent': {
              shareCommentary: {
                text: `${request.title}\n\n${request.content}`
              },
              shareMediaCategory: 'NONE'
            }
          },
          visibility: {
            'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC'
          }
        })
      });

      if (!response.ok) {
        throw new Error(`LinkedIn API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        platform: 'linkedin',
        success: true,
        postId: result.id,
        url: `https://linkedin.com/feed/update/${result.id}`
      };
    } catch (error) {
      throw new Error(`LinkedIn publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async publishToTwitter(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      // Twitter API v2
      const tweetText = `${request.title}\n\n${request.content}`.substring(0, 280);
      
      const response = await fetch('https://api.twitter.com/2/tweets', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: tweetText
        })
      });

      if (!response.ok) {
        throw new Error(`Twitter API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        platform: 'twitter',
        success: true,
        postId: result.data.id,
        url: `https://twitter.com/user/status/${result.data.id}`
      };
    } catch (error) {
      throw new Error(`Twitter publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async publishToMedium(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      const response = await fetch(`https://api.medium.com/v1/users/${config.config?.userId}/posts`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: request.title,
          contentFormat: 'markdown',
          content: request.content,
          publishStatus: 'public',
          tags: request.metadata?.tags || []
        })
      });

      if (!response.ok) {
        throw new Error(`Medium API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        platform: 'medium',
        success: true,
        postId: result.data.id,
        url: result.data.url
      };
    } catch (error) {
      throw new Error(`Medium publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async publishToWordPress(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      const wpUrl = config.config?.siteUrl || 'wordpress.com';
      const response = await fetch(`${wpUrl}/wp-json/wp/v2/posts`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: request.title,
          content: request.content,
          status: 'publish',
          categories: request.metadata?.categories || [],
          tags: request.metadata?.tags || []
        })
      });

      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        platform: 'wordpress',
        success: true,
        postId: result.id.toString(),
        url: result.link
      };
    } catch (error) {
      throw new Error(`WordPress publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async publishToFacebook(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      const pageId = config.config?.pageId;
      if (!pageId) {
        throw new Error('Facebook page ID not configured');
      }

      const response = await fetch(`https://graph.facebook.com/v18.0/${pageId}/feed`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `${request.title}\n\n${request.content}`,
          access_token: config.accessToken
        })
      });

      if (!response.ok) {
        throw new Error(`Facebook API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        platform: 'facebook',
        success: true,
        postId: result.id,
        url: `https://facebook.com/${pageId}/posts/${result.id.split('_')[1]}`
      };
    } catch (error) {
      throw new Error(`Facebook publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async publishToInstagram(request: PublishRequest, config: PublishingConfig): Promise<PublishResponse> {
    try {
      // Instagram requires images, so this is a placeholder for text-only content
      throw new Error('Instagram publishing requires image content');
    } catch (error) {
      throw new Error(`Instagram publishing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async scheduleContent(request: PublishRequest, configs: PublishingConfig[]): Promise<{
    scheduled: number;
    errors: string[];
  }> {
    let scheduled = 0;
    const errors: string[] = [];

    // For scheduling, we would typically use a job queue like Bull
    // For now, we'll just validate the request
    
    for (const platform of request.platforms) {
      const config = configs.find(c => c.platform === platform);
      if (!config) {
        errors.push(`No configuration found for platform: ${platform}`);
        continue;
      }

      // Validate scheduling is supported for platform
      const supportedPlatforms = ['linkedin', 'twitter', 'facebook', 'medium'];
      if (!supportedPlatforms.includes(platform.toLowerCase())) {
        errors.push(`Scheduling not supported for platform: ${platform}`);
        continue;
      }

      scheduled++;
    }

    return { scheduled, errors };
  }

  async getPublishingAnalytics(platform: string, postId: string, config: PublishingConfig): Promise<{
    views: number;
    likes: number;
    shares: number;
    comments: number;
    clicks: number;
  }> {
    // Platform-specific analytics fetching
    switch (platform.toLowerCase()) {
      case 'linkedin':
        return await this.getLinkedInAnalytics(postId, config);
      case 'twitter':
        return await this.getTwitterAnalytics(postId, config);
      case 'facebook':
        return await this.getFacebookAnalytics(postId, config);
      default:
        return { views: 0, likes: 0, shares: 0, comments: 0, clicks: 0 };
    }
  }

  private async getLinkedInAnalytics(postId: string, config: PublishingConfig) {
    try {
      const response = await fetch(`https://api.linkedin.com/v2/socialActions/${postId}`, {
        headers: {
          'Authorization': `Bearer ${config.accessToken}`,
          'X-Restli-Protocol-Version': '2.0.0'
        }
      });

      if (!response.ok) {
        throw new Error(`LinkedIn analytics error: ${response.status}`);
      }

      const result = await response.json();
      return {
        views: result.totalSocialActivityCounts?.numViews || 0,
        likes: result.totalSocialActivityCounts?.numLikes || 0,
        shares: result.totalSocialActivityCounts?.numShares || 0,
        comments: result.totalSocialActivityCounts?.numComments || 0,
        clicks: result.totalSocialActivityCounts?.numClicks || 0
      };
    } catch (error) {
      console.error('LinkedIn analytics error:', error);
      return { views: 0, likes: 0, shares: 0, comments: 0, clicks: 0 };
    }
  }

  private async getTwitterAnalytics(postId: string, config: PublishingConfig) {
    try {
      const response = await fetch(`https://api.twitter.com/2/tweets/${postId}?tweet.fields=public_metrics`, {
        headers: {
          'Authorization': `Bearer ${config.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error(`Twitter analytics error: ${response.status}`);
      }

      const result = await response.json();
      const metrics = result.data.public_metrics;
      
      return {
        views: metrics.impression_count || 0,
        likes: metrics.like_count || 0,
        shares: metrics.retweet_count || 0,
        comments: metrics.reply_count || 0,
        clicks: metrics.url_link_clicks || 0
      };
    } catch (error) {
      console.error('Twitter analytics error:', error);
      return { views: 0, likes: 0, shares: 0, comments: 0, clicks: 0 };
    }
  }

  private async getFacebookAnalytics(postId: string, config: PublishingConfig) {
    try {
      const response = await fetch(`https://graph.facebook.com/v18.0/${postId}?fields=insights&access_token=${config.accessToken}`);

      if (!response.ok) {
        throw new Error(`Facebook analytics error: ${response.status}`);
      }

      const result = await response.json();
      // Facebook insights structure varies, this is simplified
      
      return {
        views: 0, // Facebook doesn't provide simple view count
        likes: result.likes?.summary?.total_count || 0,
        shares: result.shares?.count || 0,
        comments: result.comments?.summary?.total_count || 0,
        clicks: 0 // Would need specific insights for clicks
      };
    } catch (error) {
      console.error('Facebook analytics error:', error);
      return { views: 0, likes: 0, shares: 0, comments: 0, clicks: 0 };
    }
  }
}

export const publishingService = new PublishingService();
