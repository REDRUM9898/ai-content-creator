import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenerativeAI } from '@google/generative-ai';

export interface AIGenerationRequest {
  prompt: string;
  contentType: 'blog' | 'social' | 'email' | 'ad';
  keywords?: string[];
  tone?: string;
  length?: 'short' | 'medium' | 'long';
  targetAudience?: string;
}

export interface AIGenerationResponse {
  content: string;
  title: string;
  seoScore: number;
  readabilityScore: number;
  model: string;
}

export class AIService {
  private openai: OpenAI | null = null;
  private anthropic: Anthropic | null = null;
  private gemini: GoogleGenerativeAI | null = null;

  constructor() {
    try {
      const openaiKey = process.env.OPENAI_API_KEY;
      const anthropicKey = process.env.ANTHROPIC_API_KEY;
      const geminiKey = process.env.GOOGLE_API_KEY;

      if (openaiKey) {
        this.openai = new OpenAI({ apiKey: openaiKey });
      }

      if (anthropicKey) {
        this.anthropic = new Anthropic({ apiKey: anthropicKey });
      }

      if (geminiKey) {
        this.gemini = new GoogleGenerativeAI(geminiKey);
      }
    } catch (error) {
      console.error('Error initializing AI services:', error);
    }
  }

  async generateContent(request: AIGenerationRequest, model: 'gpt-4' | 'claude' | 'gemini'): Promise<AIGenerationResponse> {
    const prompt = this.buildPrompt(request);

    try {
      switch (model) {
        case 'gpt-4':
          return await this.generateWithOpenAI(prompt, request);
        case 'claude':
          return await this.generateWithClaude(prompt, request);
        case 'gemini':
          return await this.generateWithGemini(prompt, request);
        default:
          throw new Error(`Unsupported model: ${model}`);
      }
    } catch (error) {
      console.error(`Error generating content with ${model}:`, error);
      throw new Error(`Failed to generate content with ${model}`);
    }
  }

  private buildPrompt(request: AIGenerationRequest): string {
    const { prompt, contentType, keywords, tone, length, targetAudience } = request;
    
    let systemPrompt = `You are an expert content creator. Generate high-quality, engaging ${contentType} content.`;
    
    if (keywords?.length) {
      systemPrompt += ` Include these keywords naturally: ${keywords.join(', ')}.`;
    }
    
    if (tone) {
      systemPrompt += ` Use a ${tone} tone.`;
    }
    
    if (targetAudience) {
      systemPrompt += ` Target audience: ${targetAudience}.`;
    }
    
    if (length) {
      const lengthMap = {
        short: '100-300 words',
        medium: '300-800 words',
        long: '800-1500 words'
      };
      systemPrompt += ` Length: ${lengthMap[length]}.`;
    }

    systemPrompt += ` Provide the response in JSON format with "title" and "content" fields.`;
    
    return `${systemPrompt}\n\nUser request: ${prompt}`;
  }

  private async generateWithOpenAI(prompt: string, request: AIGenerationRequest): Promise<AIGenerationResponse> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: prompt },
        { role: 'user', content: request.prompt }
      ],
      temperature: 0.7,
      max_tokens: 2000,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No content generated');
    }

    try {
      const parsed = JSON.parse(content);
      return {
        content: parsed.content,
        title: parsed.title,
        seoScore: this.calculateSEOScore(parsed.content, request.keywords),
        readabilityScore: this.calculateReadabilityScore(parsed.content),
        model: 'gpt-4'
      };
    } catch {
      // Fallback if not JSON
      return {
        content,
        title: this.extractTitle(content),
        seoScore: this.calculateSEOScore(content, request.keywords),
        readabilityScore: this.calculateReadabilityScore(content),
        model: 'gpt-4'
      };
    }
  }

  private async generateWithClaude(prompt: string, request: AIGenerationRequest): Promise<AIGenerationResponse> {
    if (!this.anthropic) {
      throw new Error('Anthropic API key not configured');
    }

    const response = await this.anthropic.messages.create({
      model: 'claude-3-sonnet-20240229',
      max_tokens: 2000,
      messages: [
        { role: 'user', content: prompt }
      ],
    });

    const content = response.content[0];
    if (content.type !== 'text') {
      throw new Error('Invalid response type from Claude');
    }

    const textContent = content.text;

    try {
      const parsed = JSON.parse(textContent);
      return {
        content: parsed.content,
        title: parsed.title,
        seoScore: this.calculateSEOScore(parsed.content, request.keywords),
        readabilityScore: this.calculateReadabilityScore(parsed.content),
        model: 'claude'
      };
    } catch {
      return {
        content: textContent,
        title: this.extractTitle(textContent),
        seoScore: this.calculateSEOScore(textContent, request.keywords),
        readabilityScore: this.calculateReadabilityScore(textContent),
        model: 'claude'
      };
    }
  }

  private async generateWithGemini(prompt: string, request: AIGenerationRequest): Promise<AIGenerationResponse> {
    if (!this.gemini) {
      throw new Error('Google API key not configured');
    }

    const model = this.gemini.getGenerativeModel({ model: 'gemini-pro' });
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const content = response.text();

    if (!content) {
      throw new Error('No content generated');
    }

    try {
      const parsed = JSON.parse(content);
      return {
        content: parsed.content,
        title: parsed.title,
        seoScore: this.calculateSEOScore(parsed.content, request.keywords),
        readabilityScore: this.calculateReadabilityScore(parsed.content),
        model: 'gemini'
      };
    } catch {
      return {
        content,
        title: this.extractTitle(content),
        seoScore: this.calculateSEOScore(content, request.keywords),
        readabilityScore: this.calculateReadabilityScore(content),
        model: 'gemini'
      };
    }
  }

  private extractTitle(content: string): string {
    const lines = content.split('\n').filter(line => line.trim());
    const firstLine = lines[0] || 'Generated Content';
    return firstLine.replace(/^#+\s*/, '').substring(0, 100);
  }

  private calculateSEOScore(content: string, keywords?: string[]): number {
    let score = 50; // Base score
    
    if (keywords?.length) {
      const keywordCount = keywords.filter(keyword => 
        content.toLowerCase().includes(keyword.toLowerCase())
      ).length;
      score += (keywordCount / keywords.length) * 30;
    }

    // Check content length
    const wordCount = content.split(/\s+/).length;
    if (wordCount >= 300) score += 10;
    if (wordCount >= 600) score += 10;

    return Math.min(100, Math.round(score));
  }

  private calculateReadabilityScore(content: string): number {
    const sentences = content.split(/[.!?]+/).length;
    const words = content.split(/\s+/).length;
    const avgWordsPerSentence = words / sentences;
    
    // Simple readability score (lower is better, inverted for our scale)
    let score = 100 - (avgWordsPerSentence * 2);
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  async optimizeForSEO(content: string, keywords: string[]): Promise<{
    optimizedContent: string;
    suggestions: string[];
    score: number;
  }> {
    // Simple SEO optimization logic
    let optimizedContent = content;
    const suggestions: string[] = [];
    
    // Check keyword density
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      const matches = (content.match(regex) || []).length;
      const density = (matches / content.split(/\s+/).length) * 100;
      
      if (density < 0.5) {
        suggestions.push(`Consider adding "${keyword}" more frequently (current density: ${density.toFixed(1)}%)`);
      } else if (density > 3) {
        suggestions.push(`Reduce usage of "${keyword}" to avoid keyword stuffing (current density: ${density.toFixed(1)}%)`);
      }
    });

    // Check content structure
    if (!content.includes('#') && !content.includes('<h')) {
      suggestions.push('Add headers to improve content structure');
    }

    const score = this.calculateSEOScore(optimizedContent, keywords);
    
    return {
      optimizedContent,
      suggestions,
      score
    };
  }
}

export const aiService = new AIService();
