
#!/bin/bash

echo "🚀 Building for production..."
npm run build

echo "✅ Build complete!"
echo ""
echo "📋 Deployment checklist:"
echo "1. Set up PostgreSQL database"
echo "2. Add environment variables:"
echo "   - DATABASE_URL"
echo "   - OPENAI_API_KEY"
echo "   - ANTHROPIC_API_KEY" 
echo "   - GOOGLE_AI_API_KEY"
echo "   - SESSION_SECRET"
echo "3. Run: npm start"
echo ""
echo "🌐 Free deployment platforms:"
echo "- Vercel: vercel.com"
echo "- Netlify: netlify.com"
echo "- Railway: railway.app"
echo "- Render: render.com"
