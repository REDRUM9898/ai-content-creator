
# AI Content Creator Platform

A comprehensive platform for AI-powered content generation, analytics tracking, and revenue optimization.

## Features

- **AI Content Generation**: Multiple AI models (OpenAI, Anthropic, Google Generative AI)
- **Analytics Dashboard**: Real-time performance tracking and insights
- **Revenue Tracking**: Monetization metrics and growth analysis
- **SEO Optimization**: Built-in SEO tools and recommendations
- **Content Scheduling**: Automated publishing across platforms
- **Platform Integrations**: Social media and content platform APIs

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **AI Services**: OpenAI, Anthropic Claude, Google Generative AI

## Setup

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables:
   - `DATABASE_URL`: PostgreSQL connection string
   - `OPENAI_API_KEY`: OpenAI API key
   - `ANTHROPIC_API_KEY`: Anthropic API key
   - `GOOGLE_AI_API_KEY`: Google AI API key

## Development

```bash
npm run dev
```

## Production Build

```bash
npm run build
npm start
```

## Free Deployment Options

- **Vercel**: Connect your GitHub repo for automatic deployments
- **Netlify**: Deploy frontend with serverless functions
- **Railway**: Full-stack deployment with PostgreSQL
- **Render**: Free tier with build minutes
- **Heroku**: Free tier (limited hours)

## Environment Variables

Create a `.env` file with:
```
DATABASE_URL=your_postgresql_url
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
GOOGLE_AI_API_KEY=your_google_ai_key
```

## License

MIT License - You are free to use this code for personal and commercial projects.
