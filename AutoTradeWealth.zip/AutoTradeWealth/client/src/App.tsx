import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Sidebar from "@/components/sidebar";
import Dashboard from "@/pages/dashboard";
import ContentGenerator from "@/pages/content-generator";
import SEOOptimizer from "@/pages/seo-optimizer";
import Analytics from "@/pages/analytics";
import RevenueTracking from "@/pages/revenue-tracking";
import ContentScheduler from "@/pages/content-scheduler";
import Settings from "@/pages/settings";
import Login from "@/pages/login";
import NotFound from "@/pages/not-found";

function Router() {
  const { data: authStatus, isLoading } = useQuery({
    queryKey: ["/api/auth/check"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark-primary flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-neon-purple border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!authStatus?.authenticated) {
    return <Login />;
  }

  return (
    <div className="flex min-h-screen bg-dark-primary">
      <Sidebar />
      <main className="flex-1 ml-64">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/content-generator" component={ContentGenerator} />
          <Route path="/seo-optimizer" component={SEOOptimizer} />
          <Route path="/analytics" component={Analytics} />
          <Route path="/revenue-tracking" component={RevenueTracking} />
          <Route path="/content-scheduler" component={ContentScheduler} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
