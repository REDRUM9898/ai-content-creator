import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useAppStore } from "@/lib/store";
import { Plus, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import MetricsCards from "@/components/dashboard/metrics-cards";
import RevenueChart from "@/components/dashboard/revenue-chart";
import AIModelsPerformance from "@/components/dashboard/ai-models-performance";
import QuickGeneration from "@/components/dashboard/quick-generation";
import RecentActivity from "@/components/dashboard/recent-activity";
import AdvancedAnalytics from "@/components/dashboard/advanced-analytics";
import PlatformIntegrations from "@/components/dashboard/platform-integrations";

export default function Dashboard() {
  const { setMetrics, setAIModels, setIntegrations } = useAppStore();

  // Fetch dashboard metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['/api/analytics/metrics'],
    onSuccess: (data) => setMetrics(data),
  });

  // Fetch AI models
  const { data: aiModels } = useQuery({
    queryKey: ['/api/ai/models'],
    onSuccess: (data) => setAIModels(data),
  });

  // Fetch integrations
  const { data: integrations } = useQuery({
    queryKey: ['/api/integrations'],
    onSuccess: (data) => setIntegrations(data),
  });

  return (
    <div className="min-h-screen bg-dark-primary">
      {/* Header */}
      <header className="glass-effect border-b border-gray-800 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Content Performance Dashboard</h1>
            <p className="text-gray-400 mt-1">Track your AI-generated content performance and revenue in real-time</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button className="bg-gradient-to-r from-neon-purple to-neon-cyan hover:from-neon-cyan hover:to-neon-purple border border-neon-purple/30 neon-glow-purple">
              <Plus className="w-4 h-4 mr-2" />
              New Campaign
            </Button>
            <div className="relative">
              <Button variant="ghost" size="sm" className="glass-effect hover:bg-gray-800 relative">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-neon-green rounded-full"></span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 space-y-6">
        {/* Key Metrics */}
        <MetricsCards metrics={metrics} loading={metricsLoading} />

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Revenue Chart */}
          <RevenueChart metrics={metrics} className="lg:col-span-2" />
          
          {/* AI Models Performance */}
          <AIModelsPerformance models={aiModels} />
        </div>

        {/* Content Generation Hub */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <QuickGeneration />
          <RecentActivity />
        </div>

        {/* Advanced Analytics */}
        <AdvancedAnalytics metrics={metrics} />

        {/* Platform Integrations */}
        <PlatformIntegrations integrations={integrations} />
      </main>
    </div>
  );
}
