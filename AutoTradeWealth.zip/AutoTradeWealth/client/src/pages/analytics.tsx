import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DatePickerWithRange } from "@/components/ui/date-picker";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, Eye, MousePointer, Share2, DollarSign, Download, Filter } from "lucide-react";
import { api } from "@/lib/api";
import { useState } from "react";

export default function Analytics() {
  const [dateRange, setDateRange] = useState<any>(null);
  const [selectedPlatform, setSelectedPlatform] = useState("all");

  const { data: metrics } = useQuery({
    queryKey: ['/api/analytics/metrics'],
  });

  const { data: report } = useQuery({
    queryKey: ['/api/analytics/report', dateRange],
    enabled: !!dateRange,
  });

  // Mock data for charts (in real app, this would come from the API)
  const performanceData = [
    { date: "Jan", views: 45000, clicks: 3200, conversions: 156, revenue: 1240 },
    { date: "Feb", views: 52000, clicks: 4100, conversions: 203, revenue: 1820 },
    { date: "Mar", views: 61000, clicks: 4800, conversions: 278, revenue: 2450 },
    { date: "Apr", views: 70000, clicks: 5500, conversions: 312, revenue: 2890 },
    { date: "May", views: 85000, clicks: 6800, conversions: 398, revenue: 3580 },
  ];

  const platformData = [
    { name: "LinkedIn", value: 35, color: "#0077B5" },
    { name: "Twitter", value: 25, color: "#1DA1F2" },
    { name: "Medium", value: 20, color: "#00AB6C" },
    { name: "Facebook", value: 15, color: "#1877F2" },
    { name: "Others", value: 5, color: "#6B7280" },
  ];

  const contentTypeData = [
    { type: "Blog Posts", performance: 85, count: 124 },
    { type: "Social Media", performance: 78, count: 89 },
    { type: "Email Campaigns", performance: 92, count: 45 },
    { type: "Advertisements", performance: 71, count: 67 },
  ];

  const analyticsCards = [
    {
      title: "Total Views",
      value: metrics?.totalViews?.toLocaleString() || "0",
      change: "+31.4%",
      icon: Eye,
      color: "neon-cyan",
    },
    {
      title: "Click-through Rate",
      value: `${(metrics?.conversionRate || 0).toFixed(1)}%`,
      change: "+12.3%",
      icon: MousePointer,
      color: "neon-purple",
    },
    {
      title: "Engagement Rate",
      value: `${(metrics?.engagementRate || 0).toFixed(1)}%`,
      change: "+18.7%",
      icon: Share2,
      color: "neon-green",
    },
    {
      title: "Revenue Generated",
      value: `$${(metrics?.totalRevenue || 0).toLocaleString()}`,
      change: "+25.1%",
      icon: DollarSign,
      color: "orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text">Analytics Dashboard</h1>
            <p className="text-gray-400 mt-2">Track your content performance and audience insights</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-[180px] glass-effect border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="all">All Platforms</SelectItem>
                <SelectItem value="linkedin">LinkedIn</SelectItem>
                <SelectItem value="twitter">Twitter</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-neon-purple/20 text-neon-purple border border-neon-purple/30">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {analyticsCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <Card 
                key={card.title}
                className={`glass-effect border-${card.color}/30 chart-animation hover-lift`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 bg-${card.color}/20 rounded-lg flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 text-${card.color}`} />
                    </div>
                    <span className={`text-sm text-${card.color} font-medium`}>{card.change}</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">{card.title}</p>
                    <p className={`text-2xl font-bold text-${card.color}`}>{card.value}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="performance" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="performance" className="text-white">Performance</TabsTrigger>
            <TabsTrigger value="audience" className="text-white">Audience</TabsTrigger>
            <TabsTrigger value="content" className="text-white">Content Analysis</TabsTrigger>
            <TabsTrigger value="revenue" className="text-white">Revenue</TabsTrigger>
          </TabsList>

          <TabsContent value="performance" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Views and Engagement Chart */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Views & Engagement</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="date" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="views"
                          stackId="1"
                          stroke="hsl(197, 100%, 50%)"
                          fill="hsl(197, 100%, 50%)"
                          fillOpacity={0.3}
                        />
                        <Area
                          type="monotone"
                          dataKey="clicks"
                          stackId="1"
                          stroke="hsl(251, 91%, 67%)"
                          fill="hsl(251, 91%, 67%)"
                          fillOpacity={0.3}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Conversion Funnel */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Conversion Funnel</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { stage: "Impressions", value: 85000, percentage: 100 },
                      { stage: "Clicks", value: 6800, percentage: 8 },
                      { stage: "Engagements", value: 1200, percentage: 1.4 },
                      { stage: "Conversions", value: 398, percentage: 0.47 },
                    ].map((item, index) => (
                      <div key={item.stage} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-white">{item.stage}</span>
                          <span className="text-gray-400">{item.value.toLocaleString()} ({item.percentage}%)</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-neon-cyan to-neon-purple h-2 rounded-full transition-all duration-500"
                            style={{ width: `${item.percentage * 10}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="audience" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Platform Distribution */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Platform Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={platformData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={120}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {platformData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex flex-wrap gap-4 mt-4">
                    {platformData.map((platform) => (
                      <div key={platform.name} className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: platform.color }}
                        />
                        <span className="text-sm text-gray-300">{platform.name}: {platform.value}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Audience Growth */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Audience Growth</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="date" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="views"
                          stroke="hsl(160, 84%, 39%)"
                          strokeWidth={3}
                          dot={{ fill: 'hsl(160, 84%, 39%)', strokeWidth: 2, r: 4 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="content" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Content Type Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {contentTypeData.map((item) => (
                    <div key={item.type} className="p-4 bg-gray-800/50 rounded-lg">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="text-white font-medium">{item.type}</h4>
                        <div className="text-right">
                          <span className="text-neon-cyan font-semibold">{item.performance}%</span>
                          <p className="text-xs text-gray-400">{item.count} pieces</p>
                        </div>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-neon-cyan to-neon-green h-2 rounded-full"
                          style={{ width: `${item.performance}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Revenue Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="date" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#111111',
                          border: '1px solid #374151',
                          borderRadius: '8px',
                          color: '#fff'
                        }}
                      />
                      <Bar dataKey="revenue" fill="hsl(160, 84%, 39%)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
