import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wand2, Brain, Cpu, Gem, Copy, Save, Share, Loader2, Plus, X } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useAppStore } from "@/lib/store";

export default function ContentGenerator() {
  const [prompt, setPrompt] = useState("");
  const [contentType, setContentType] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt-4");
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState("");
  const [tone, setTone] = useState("");
  const [length, setLength] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [generatedContent, setGeneratedContent] = useState<any>(null);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);

  const { toast } = useToast();
  const { addContent } = useAppStore();
  const queryClient = useQueryClient();

  const { data: aiModels } = useQuery({
    queryKey: ['/api/ai/models'],
  });

  const generateMutation = useMutation({
    mutationFn: (data: any) => api.ai.generate(data),
    onSuccess: (data) => {
      setGeneratedContent(data);
      toast({
        title: "Content Generated Successfully",
        description: "Your AI-generated content is ready for review.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) => api.content.create(data),
    onSuccess: (data) => {
      addContent(data);
      queryClient.invalidateQueries({ queryKey: ['/api/content'] });
      toast({
        title: "Content Saved",
        description: "Your content has been saved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Save Failed",
        description: error.message || "Failed to save content.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt || !contentType) {
      toast({
        title: "Missing Information",
        description: "Please provide a prompt and select content type.",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      prompt,
      contentType,
      keywords,
      tone,
      length,
      targetAudience,
      model: selectedModel,
    });
  };

  const handleSave = () => {
    if (!generatedContent) return;

    saveMutation.mutate({
      title: generatedContent.title,
      body: generatedContent.content,
      type: contentType,
      status: 'generated',
      aiModel: selectedModel,
      keywords,
      platforms: selectedPlatforms,
      metadata: {
        seoScore: generatedContent.seoScore,
        readabilityScore: generatedContent.readabilityScore,
        tone,
        length,
        targetAudience,
      },
    });
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword("");
    }
  };

  const removeKeyword = (keyword: string) => {
    setKeywords(keywords.filter(k => k !== keyword));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to Clipboard",
      description: "Content has been copied to your clipboard.",
    });
  };

  const modelIcons = {
    'gpt-4': Brain,
    'claude': Cpu,
    'gemini': Gem,
  };

  const platforms = [
    { id: "linkedin", name: "LinkedIn", color: "blue-400" },
    { id: "twitter", name: "Twitter", color: "blue-400" },
    { id: "medium", name: "Medium", color: "gray-400" },
    { id: "facebook", name: "Facebook", color: "blue-600" },
    { id: "instagram", name: "Instagram", color: "pink-400" },
    { id: "youtube", name: "YouTube", color: "red-500" },
  ];

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text">AI Content Generator</h1>
            <p className="text-gray-400 mt-2">Create high-quality content with advanced AI models</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Generation Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Wand2 className="w-5 h-5 text-neon-cyan" />
                  Content Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                    <TabsTrigger value="basic" className="text-white">Basic Settings</TabsTrigger>
                    <TabsTrigger value="advanced" className="text-white">Advanced Settings</TabsTrigger>
                  </TabsList>

                  <TabsContent value="basic" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white mb-2 block">Content Type</Label>
                        <Select value={contentType} onValueChange={setContentType}>
                          <SelectTrigger className="glass-effect border-gray-600 text-white">
                            <SelectValue placeholder="Select content type" />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            <SelectItem value="blog">Blog Post</SelectItem>
                            <SelectItem value="social">Social Media Post</SelectItem>
                            <SelectItem value="email">Email Campaign</SelectItem>
                            <SelectItem value="ad">Advertisement</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-white mb-2 block">AI Model</Label>
                        <Select value={selectedModel} onValueChange={setSelectedModel}>
                          <SelectTrigger className="glass-effect border-gray-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            {aiModels?.map((model: any) => {
                              const Icon = modelIcons[model.model as keyof typeof modelIcons] || Brain;
                              return (
                                <SelectItem key={model.id} value={model.model}>
                                  <div className="flex items-center gap-2">
                                    <Icon className="w-4 h-4" />
                                    {model.name}
                                  </div>
                                </SelectItem>
                              );
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label className="text-white mb-2 block">Content Prompt</Label>
                      <Textarea
                        placeholder="Describe what you want to create..."
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="glass-effect border-gray-600 text-white bg-transparent min-h-[120px] focus:border-neon-cyan"
                      />
                    </div>

                    <div>
                      <Label className="text-white mb-2 block">Keywords</Label>
                      <div className="flex gap-2 mb-2">
                        <Input
                          placeholder="Add a keyword..."
                          value={newKeyword}
                          onChange={(e) => setNewKeyword(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && addKeyword()}
                          className="glass-effect border-gray-600 text-white bg-transparent"
                        />
                        <Button onClick={addKeyword} size="sm" className="bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {keywords.map((keyword) => (
                          <Badge key={keyword} variant="secondary" className="bg-gray-700 text-white">
                            {keyword}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeKeyword(keyword)}
                              className="ml-1 h-auto p-0 hover:bg-transparent"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="advanced" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-white mb-2 block">Tone</Label>
                        <Select value={tone} onValueChange={setTone}>
                          <SelectTrigger className="glass-effect border-gray-600 text-white">
                            <SelectValue placeholder="Select tone" />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            <SelectItem value="professional">Professional</SelectItem>
                            <SelectItem value="casual">Casual</SelectItem>
                            <SelectItem value="friendly">Friendly</SelectItem>
                            <SelectItem value="authoritative">Authoritative</SelectItem>
                            <SelectItem value="conversational">Conversational</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-white mb-2 block">Length</Label>
                        <Select value={length} onValueChange={setLength}>
                          <SelectTrigger className="glass-effect border-gray-600 text-white">
                            <SelectValue placeholder="Select length" />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-600">
                            <SelectItem value="short">Short (100-300 words)</SelectItem>
                            <SelectItem value="medium">Medium (300-800 words)</SelectItem>
                            <SelectItem value="long">Long (800-1500 words)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-white mb-2 block">Target Audience</Label>
                        <Input
                          placeholder="e.g., Tech professionals"
                          value={targetAudience}
                          onChange={(e) => setTargetAudience(e.target.value)}
                          className="glass-effect border-gray-600 text-white bg-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-white mb-2 block">Target Platforms</Label>
                      <div className="flex flex-wrap gap-2">
                        {platforms.map((platform) => (
                          <Button
                            key={platform.id}
                            size="sm"
                            variant={selectedPlatforms.includes(platform.id) ? "default" : "outline"}
                            onClick={() => {
                              setSelectedPlatforms(prev =>
                                prev.includes(platform.id)
                                  ? prev.filter(p => p !== platform.id)
                                  : [...prev, platform.id]
                              );
                            }}
                            className={
                              selectedPlatforms.includes(platform.id)
                                ? "bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30"
                                : "bg-gray-800 text-gray-400 border border-gray-600 hover:border-neon-cyan hover:text-neon-cyan"
                            }
                          >
                            {platform.name}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending}
                  className="w-full bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-purple hover:to-neon-cyan text-white font-semibold neon-glow"
                >
                  {generateMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating Content...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4 mr-2" />
                      Generate Content
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Generated Content Preview */}
          <div className="space-y-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Generated Content</CardTitle>
              </CardHeader>
              <CardContent>
                {generatedContent ? (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white mb-2 block">Title</Label>
                      <div className="glass-effect border border-gray-600 rounded-lg p-3 text-white">
                        {generatedContent.title}
                      </div>
                    </div>

                    <div>
                      <Label className="text-white mb-2 block">Content</Label>
                      <div className="glass-effect border border-gray-600 rounded-lg p-3 text-white max-h-96 overflow-y-auto">
                        <pre className="whitespace-pre-wrap font-sans">
                          {generatedContent.content}
                        </pre>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <p className="text-xs text-gray-400">SEO Score</p>
                        <p className="text-lg font-bold text-neon-green">
                          {generatedContent.seoScore}%
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-400">Readability</p>
                        <p className="text-lg font-bold text-neon-cyan">
                          {generatedContent.readabilityScore}%
                        </p>
                      </div>
                    </div>

                    <Separator className="bg-gray-600" />

                    <div className="flex gap-2">
                      <Button
                        onClick={() => copyToClipboard(generatedContent.content)}
                        variant="outline"
                        size="sm"
                        className="flex-1 border-gray-600 text-gray-300 hover:text-white"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy
                      </Button>
                      <Button
                        onClick={handleSave}
                        disabled={saveMutation.isPending}
                        size="sm"
                        className="flex-1 bg-neon-green/20 text-neon-green border border-neon-green/30 hover:bg-neon-green/30"
                      >
                        {saveMutation.isPending ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Save className="w-4 h-4 mr-2" />
                        )}
                        Save
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <Wand2 className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>No content generated yet</p>
                    <p className="text-sm">Configure your settings and click generate</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
