import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Settings as SettingsIcon, Key, Bell, Palette, Shield, Trash2, Plus, ExternalLink } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("integrations");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: integrations } = useQuery({
    queryKey: ['/api/integrations'],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.integrations.delete(id),
    onSuccess: () => {
      toast({
        title: "Integration Removed",
        description: "The integration has been successfully removed.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
    },
    onError: (error: any) => {
      toast({
        title: "Removal Failed",
        description: error.message || "Failed to remove integration.",
        variant: "destructive",
      });
    },
  });

  const platformConfigs = [
    {
      platform: "linkedin",
      name: "LinkedIn",
      description: "Connect your LinkedIn profile for professional content sharing",
      icon: "🔗",
      color: "blue-500",
      setupUrl: "https://linkedin.com/oauth/authorize",
    },
    {
      platform: "twitter",
      name: "Twitter",
      description: "Share your content on Twitter for maximum reach",
      icon: "🐦",
      color: "blue-400",
      setupUrl: "https://twitter.com/oauth/authorize",
    },
    {
      platform: "medium",
      name: "Medium",
      description: "Publish long-form content on Medium",
      icon: "📝",
      color: "gray-600",
      setupUrl: "https://medium.com/oauth/authorize",
    },
    {
      platform: "wordpress",
      name: "WordPress",
      description: "Connect your WordPress site for blog publishing",
      icon: "📰",
      color: "blue-600",
      setupUrl: "https://wordpress.com/oauth/authorize",
    },
    {
      platform: "mailchimp",
      name: "Mailchimp",
      description: "Send email campaigns through Mailchimp",
      icon: "📧",
      color: "yellow-500",
      setupUrl: "https://mailchimp.com/oauth/authorize",
    },
  ];

  const getIntegrationStatus = (platform: string) => {
    return integrations?.find((integration: any) => integration.platform === platform);
  };

  const handleConnect = (platform: string) => {
    // In a real app, this would initiate OAuth flow
    toast({
      title: "OAuth Setup",
      description: `Redirecting to ${platform} for authorization...`,
    });
  };

  const handleDisconnect = (integrationId: number) => {
    deleteMutation.mutate(integrationId);
  };

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-r from-neon-cyan to-neon-purple rounded-lg flex items-center justify-center neon-glow">
            <SettingsIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold gradient-text">Settings</h1>
            <p className="text-gray-400 mt-1">Manage your account and platform integrations</p>
          </div>
        </div>

        {/* Settings Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gray-800">
            <TabsTrigger value="integrations" className="text-white">Integrations</TabsTrigger>
            <TabsTrigger value="api" className="text-white">API Keys</TabsTrigger>
            <TabsTrigger value="notifications" className="text-white">Notifications</TabsTrigger>
            <TabsTrigger value="appearance" className="text-white">Appearance</TabsTrigger>
            <TabsTrigger value="security" className="text-white">Security</TabsTrigger>
          </TabsList>

          {/* Platform Integrations */}
          <TabsContent value="integrations" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Platform Integrations</CardTitle>
                <p className="text-gray-400 text-sm">Connect your social media and publishing platforms</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {platformConfigs.map((platform) => {
                  const integration = getIntegrationStatus(platform.platform);
                  const isConnected = !!integration;

                  return (
                    <div key={platform.platform} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg hover-lift">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 bg-${platform.color}/20 rounded-lg flex items-center justify-center text-2xl`}>
                          {platform.icon}
                        </div>
                        <div>
                          <h4 className="font-medium text-white">{platform.name}</h4>
                          <p className="text-sm text-gray-400">{platform.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {isConnected ? (
                          <>
                            <Badge className="bg-neon-green/20 text-neon-green border border-neon-green/30">
                              Connected
                            </Badge>
                            <Button
                              onClick={() => handleDisconnect(integration.id)}
                              variant="outline"
                              size="sm"
                              className="border-red-500/30 text-red-400 hover:bg-red-500/20"
                            >
                              Disconnect
                            </Button>
                          </>
                        ) : (
                          <Button
                            onClick={() => handleConnect(platform.platform)}
                            className="bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30 hover:bg-neon-cyan/30"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Connect
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Integration Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {platformConfigs.map((platform) => {
                    const isConnected = getIntegrationStatus(platform.platform);
                    return (
                      <div key={platform.platform} className="text-center p-4 bg-gray-800/50 rounded-lg">
                        <div className={`w-12 h-12 bg-${platform.color}/20 rounded-lg flex items-center justify-center mx-auto mb-2 text-2xl`}>
                          {platform.icon}
                        </div>
                        <p className="text-xs font-medium text-white">{platform.name}</p>
                        <p className={`text-xs ${isConnected ? 'text-neon-green' : 'text-gray-400'}`}>
                          {isConnected ? 'Connected' : 'Not Connected'}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API Keys */}
          <TabsContent value="api" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  AI Model API Keys
                </CardTitle>
                <p className="text-gray-400 text-sm">Configure your AI service API keys</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { service: "OpenAI", key: "OPENAI_API_KEY", placeholder: "sk-..." },
                  { service: "Anthropic", key: "ANTHROPIC_API_KEY", placeholder: "sk-ant-..." },
                  { service: "Google AI", key: "GOOGLE_API_KEY", placeholder: "AIza..." },
                ].map((apiKey) => (
                  <div key={apiKey.service} className="space-y-2">
                    <Label className="text-white">{apiKey.service} API Key</Label>
                    <div className="flex gap-2">
                      <Input
                        type="password"
                        placeholder={apiKey.placeholder}
                        className="glass-effect border-gray-600 text-white bg-transparent flex-1"
                      />
                      <Button className="bg-neon-purple/20 text-neon-purple border border-neon-purple/30">
                        Save
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Platform API Keys</CardTitle>
                <p className="text-gray-400 text-sm">API keys for publishing platforms</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { service: "Stripe", key: "STRIPE_SECRET_KEY", placeholder: "sk_..." },
                  { service: "Mailchimp", key: "MAILCHIMP_API_KEY", placeholder: "..." },
                ].map((apiKey) => (
                  <div key={apiKey.service} className="space-y-2">
                    <Label className="text-white">{apiKey.service} API Key</Label>
                    <div className="flex gap-2">
                      <Input
                        type="password"
                        placeholder={apiKey.placeholder}
                        className="glass-effect border-gray-600 text-white bg-transparent flex-1"
                      />
                      <Button className="bg-neon-purple/20 text-neon-purple border border-neon-purple/30">
                        Save
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {[
                  { label: "Content Generation Complete", description: "Get notified when AI finishes generating content" },
                  { label: "Publishing Success", description: "Notifications when content is successfully published" },
                  { label: "Publishing Errors", description: "Alerts for failed publishing attempts" },
                  { label: "Revenue Milestones", description: "Celebrate when you reach revenue goals" },
                  { label: "Weekly Reports", description: "Weekly performance summary emails" },
                  { label: "Content Suggestions", description: "AI-powered content recommendations" },
                ].map((notification) => (
                  <div key={notification.label} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">{notification.label}</h4>
                      <p className="text-sm text-gray-400">{notification.description}</p>
                    </div>
                    <Switch />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance */}
          <TabsContent value="appearance" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Palette className="w-5 h-5" />
                  Appearance Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-white mb-3 block">Theme</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-800/50 rounded-lg border border-neon-cyan/30 cursor-pointer">
                        <h4 className="font-medium text-white mb-2">Dark Mode</h4>
                        <p className="text-sm text-gray-400">Current active theme</p>
                      </div>
                      <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-600 cursor-pointer opacity-50">
                        <h4 className="font-medium text-white mb-2">Light Mode</h4>
                        <p className="text-sm text-gray-400">Coming soon</p>
                      </div>
                    </div>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div>
                    <Label className="text-white mb-3 block">Accent Color</Label>
                    <div className="flex gap-3">
                      {[
                        { name: "Cyan", color: "bg-neon-cyan", selected: true },
                        { name: "Purple", color: "bg-neon-purple", selected: false },
                        { name: "Green", color: "bg-neon-green", selected: false },
                        { name: "Orange", color: "bg-orange-500", selected: false },
                      ].map((color) => (
                        <div
                          key={color.name}
                          className={`w-12 h-12 ${color.color} rounded-lg cursor-pointer ${
                            color.selected ? 'ring-2 ring-white' : ''
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Security Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Change Password</Label>
                    <div className="space-y-3">
                      <Input
                        type="password"
                        placeholder="Current password"
                        className="glass-effect border-gray-600 text-white bg-transparent"
                      />
                      <Input
                        type="password"
                        placeholder="New password"
                        className="glass-effect border-gray-600 text-white bg-transparent"
                      />
                      <Input
                        type="password"
                        placeholder="Confirm new password"
                        className="glass-effect border-gray-600 text-white bg-transparent"
                      />
                      <Button className="bg-neon-green/20 text-neon-green border border-neon-green/30">
                        Update Password
                      </Button>
                    </div>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-white">Two-Factor Authentication</h4>
                        <p className="text-sm text-gray-400">Add an extra layer of security to your account</p>
                      </div>
                      <Button className="bg-neon-purple/20 text-neon-purple border border-neon-purple/30">
                        Enable 2FA
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-white">Active Sessions</h4>
                        <p className="text-sm text-gray-400">Manage your active login sessions</p>
                      </div>
                      <Button variant="outline" className="border-gray-600 text-gray-300">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Sessions
                      </Button>
                    </div>
                  </div>

                  <Separator className="bg-gray-600" />

                  <div className="p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
                    <h4 className="font-medium text-red-400 mb-2">Danger Zone</h4>
                    <p className="text-sm text-gray-400 mb-4">
                      These actions are irreversible. Please proceed with caution.
                    </p>
                    <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/20">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Account
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
