import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts";
import { DollarSign, TrendingUp, Target, CreditCard, Download, Calendar } from "lucide-react";
import { api } from "@/lib/api";
import { useState } from "react";

export default function RevenueTracking() {
  const [timeRange, setTimeRange] = useState("30d");
  const [revenueSource, setRevenueSource] = useState("all");

  const { data: metrics } = useQuery({
    queryKey: ['/api/analytics/metrics'],
  });

  // Mock revenue data (in real app, this would come from the API)
  const revenueData = [
    { date: "Jan", direct: 1200, affiliate: 800, ads: 600, subscriptions: 1400 },
    { date: "Feb", direct: 1500, affiliate: 950, ads: 750, subscriptions: 1600 },
    { date: "Mar", direct: 1800, affiliate: 1200, ads: 900, subscriptions: 1800 },
    { date: "Apr", direct: 2200, affiliate: 1400, ads: 1100, subscriptions: 2000 },
    { date: "May", direct: 2600, affiliate: 1650, ads: 1300, subscriptions: 2200 },
  ];

  const monthlyGrowth = [
    { month: "Jan", revenue: 4000, growth: 15 },
    { month: "Feb", revenue: 4800, growth: 20 },
    { month: "Mar", revenue: 5700, growth: 18.75 },
    { month: "Apr", revenue: 6700, growth: 17.54 },
    { month: "May", revenue: 7750, growth: 15.67 },
  ];

  const revenueStreams = [
    { source: "Direct Sales", amount: 15420, percentage: 42, growth: "+23%" },
    { source: "Affiliate Marketing", amount: 8960, percentage: 24, growth: "+18%" },
    { source: "Advertising Revenue", amount: 6540, percentage: 18, growth: "+15%" },
    { source: "Subscriptions", amount: 5830, percentage: 16, growth: "+31%" },
  ];

  const topPerformers = [
    { content: "AI Marketing Strategies", revenue: 2840, platform: "LinkedIn" },
    { content: "Content Creation Guide", revenue: 2150, platform: "Medium" },
    { content: "SEO Optimization Tips", revenue: 1920, platform: "Twitter" },
    { content: "Email Marketing Course", revenue: 1760, platform: "Email" },
    { content: "Social Media Templates", revenue: 1650, platform: "Multiple" },
  ];

  const revenueCards = [
    {
      title: "Total Revenue",
      value: `$${(metrics?.totalRevenue || 36750).toLocaleString()}`,
      change: "+23.5%",
      icon: DollarSign,
      color: "neon-green",
    },
    {
      title: "Monthly Revenue",
      value: `$${(metrics?.monthlyRevenue || 7750).toLocaleString()}`,
      change: "+15.7%",
      icon: TrendingUp,
      color: "neon-cyan",
    },
    {
      title: "Average Per Content",
      value: "$156",
      change: "+8.2%",
      icon: Target,
      color: "neon-purple",
    },
    {
      title: "Active Revenue Streams",
      value: "12",
      change: "+3",
      icon: CreditCard,
      color: "orange-500",
    },
  ];

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text">Revenue Tracking</h1>
            <p className="text-gray-400 mt-2">Monitor your content monetization performance</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[120px] glass-effect border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="7d">7 Days</SelectItem>
                <SelectItem value="30d">30 Days</SelectItem>
                <SelectItem value="90d">90 Days</SelectItem>
                <SelectItem value="1y">1 Year</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-neon-green/20 text-neon-green border border-neon-green/30">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Revenue Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {revenueCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <Card 
                key={card.title}
                className={`glass-effect border-${card.color}/30 chart-animation hover-lift neon-glow-green`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 bg-${card.color}/20 rounded-lg flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 text-${card.color}`} />
                    </div>
                    <span className={`text-sm text-${card.color} font-medium`}>{card.change}</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">{card.title}</p>
                    <p className={`text-2xl font-bold text-${card.color}`}>{card.value}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Revenue Analytics */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="overview" className="text-white">Overview</TabsTrigger>
            <TabsTrigger value="streams" className="text-white">Revenue Streams</TabsTrigger>
            <TabsTrigger value="content" className="text-white">Content Performance</TabsTrigger>
            <TabsTrigger value="forecasting" className="text-white">Forecasting</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Revenue Trend */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Revenue Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={monthlyGrowth}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                          formatter={(value: any, name: string) => [
                            name === 'revenue' ? `$${value.toLocaleString()}` : `${value}%`,
                            name === 'revenue' ? 'Revenue' : 'Growth Rate'
                          ]}
                        />
                        <Area
                          type="monotone"
                          dataKey="revenue"
                          stroke="hsl(160, 84%, 39%)"
                          fill="hsl(160, 84%, 39%)"
                          fillOpacity={0.3}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Growth Rate */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Monthly Growth Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={monthlyGrowth}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                          formatter={(value: any) => [`${value}%`, 'Growth Rate']}
                        />
                        <Bar dataKey="growth" fill="hsl(197, 100%, 50%)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="streams" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Revenue Sources Chart */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Revenue by Source</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="date" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111111',
                            border: '1px solid #374151',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                        />
                        <Area type="monotone" dataKey="direct" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.8} />
                        <Area type="monotone" dataKey="affiliate" stackId="1" stroke="#00D4FF" fill="#00D4FF" fillOpacity={0.8} />
                        <Area type="monotone" dataKey="ads" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.8} />
                        <Area type="monotone" dataKey="subscriptions" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.8} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Revenue Streams Breakdown */}
              <Card className="glass-effect border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Revenue Streams</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {revenueStreams.map((stream) => (
                      <div key={stream.source} className="p-4 bg-gray-800/50 rounded-lg hover-lift">
                        <div className="flex justify-between items-center mb-3">
                          <span className="text-white font-medium">{stream.source}</span>
                          <div className="text-right">
                            <span className="text-neon-green font-semibold">${stream.amount.toLocaleString()}</span>
                            <p className="text-xs text-gray-400">{stream.growth}</p>
                          </div>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-neon-green to-neon-cyan h-2 rounded-full"
                            style={{ width: `${stream.percentage}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-400 mt-2">{stream.percentage}% of total revenue</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="content" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Top Performing Content</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topPerformers.map((item, index) => (
                    <div key={item.content} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg hover-lift">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 bg-neon-cyan/20 rounded-lg flex items-center justify-center">
                          <span className="text-neon-cyan font-bold">{index + 1}</span>
                        </div>
                        <div>
                          <h4 className="font-medium text-white">{item.content}</h4>
                          <p className="text-sm text-gray-400">{item.platform}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-neon-green">${item.revenue.toLocaleString()}</p>
                        <p className="text-xs text-gray-400">Revenue generated</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="forecasting" className="space-y-6 mt-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Revenue Forecast</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50 text-gray-400" />
                  <p className="text-gray-400 mb-2">Revenue Forecasting</p>
                  <p className="text-sm text-gray-500">AI-powered predictions based on your content performance trends</p>
                  <Button className="mt-4 bg-neon-purple/20 text-neon-purple border border-neon-purple/30">
                    Generate Forecast
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
