import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon, Clock, Send, Pause, Play, Plus, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { format, addDays, isSameDay } from "date-fns";

export default function ContentScheduler() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedContent, setSelectedContent] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [scheduleTime, setScheduleTime] = useState("");
  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: content } = useQuery({
    queryKey: ['/api/content'],
  });

  const { data: schedules } = useQuery({
    queryKey: ['/api/schedules'],
  });

  const scheduleMutation = useMutation({
    mutationFn: (data: any) => api.schedules.create(data),
    onSuccess: () => {
      toast({
        title: "Content Scheduled",
        description: "Your content has been scheduled for publishing.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/schedules'] });
      setSelectedContent("");
      setSelectedPlatforms([]);
      setScheduleTime("");
    },
    onError: (error: any) => {
      toast({
        title: "Scheduling Failed",
        description: error.message || "Failed to schedule content.",
        variant: "destructive",
      });
    },
  });

  const platforms = [
    { id: "linkedin", name: "LinkedIn", color: "blue-400", icon: "linkedin" },
    { id: "twitter", name: "Twitter", color: "blue-400", icon: "twitter" },
    { id: "medium", name: "Medium", color: "gray-400", icon: "medium" },
    { id: "facebook", name: "Facebook", color: "blue-600", icon: "facebook" },
    { id: "instagram", name: "Instagram", color: "pink-400", icon: "instagram" },
  ];

  const handleSchedule = () => {
    if (!selectedContent || selectedPlatforms.length === 0 || !scheduleTime) {
      toast({
        title: "Missing Information",
        description: "Please select content, platforms, and schedule time.",
        variant: "destructive",
      });
      return;
    }

    const scheduleDateTime = new Date(`${format(selectedDate, 'yyyy-MM-dd')}T${scheduleTime}`);
    
    scheduleMutation.mutate({
      contentId: parseInt(selectedContent),
      platform: selectedPlatforms[0], // For now, schedule one platform at a time
      scheduledFor: scheduleDateTime.toISOString(),
      status: 'pending',
    });
  };

  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platformId)
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    );
  };

  const getSchedulesForDate = (date: Date) => {
    return schedules?.filter((schedule: any) => 
      isSameDay(new Date(schedule.scheduledFor), date)
    ) || [];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published':
        return 'neon-green';
      case 'pending':
        return 'orange-500';
      case 'failed':
        return 'red-500';
      default:
        return 'gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'published':
        return Send;
      case 'pending':
        return Clock;
      case 'failed':
        return Pause;
      default:
        return Clock;
    }
  };

  // Quick schedule options
  const quickScheduleOptions = [
    { label: "In 1 hour", date: addDays(new Date(), 0), time: format(new Date(Date.now() + 60 * 60 * 1000), 'HH:mm') },
    { label: "Tomorrow 9 AM", date: addDays(new Date(), 1), time: "09:00" },
    { label: "Next week", date: addDays(new Date(), 7), time: "10:00" },
  ];

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text">Content Scheduler</h1>
            <p className="text-gray-400 mt-2">Schedule and manage your content publishing across platforms</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex bg-gray-800 rounded-lg">
              <Button
                variant={viewMode === "calendar" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("calendar")}
                className={viewMode === "calendar" ? "bg-neon-cyan/20 text-neon-cyan" : "text-gray-400"}
              >
                <CalendarIcon className="w-4 h-4 mr-2" />
                Calendar
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className={viewMode === "list" ? "bg-neon-cyan/20 text-neon-cyan" : "text-gray-400"}
              >
                List
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Scheduling Form */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-neon-cyan" />
                  Schedule Content
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Select Content</Label>
                  <Select value={selectedContent} onValueChange={setSelectedContent}>
                    <SelectTrigger className="glass-effect border-gray-600 text-white">
                      <SelectValue placeholder="Choose content to schedule" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {content?.map((item: any) => (
                        <SelectItem key={item.id} value={item.id.toString()}>
                          {item.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Target Platforms</Label>
                  <div className="flex flex-wrap gap-2">
                    {platforms.map(platform => (
                      <Button
                        key={platform.id}
                        size="sm"
                        variant={selectedPlatforms.includes(platform.id) ? "default" : "outline"}
                        onClick={() => togglePlatform(platform.id)}
                        className={
                          selectedPlatforms.includes(platform.id)
                            ? "bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30"
                            : "bg-gray-800 text-gray-400 border border-gray-600 hover:border-neon-cyan hover:text-neon-cyan"
                        }
                      >
                        {platform.name}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white mb-2 block">Date</Label>
                    <div className="glass-effect border border-gray-600 rounded-lg p-2 text-white text-sm">
                      {format(selectedDate, 'MMM dd, yyyy')}
                    </div>
                  </div>
                  <div>
                    <Label className="text-white mb-2 block">Time</Label>
                    <Input
                      type="time"
                      value={scheduleTime}
                      onChange={(e) => setScheduleTime(e.target.value)}
                      className="glass-effect border-gray-600 text-white bg-transparent"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Quick Schedule</Label>
                  <div className="space-y-2">
                    {quickScheduleOptions.map((option) => (
                      <Button
                        key={option.label}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedDate(option.date);
                          setScheduleTime(option.time);
                        }}
                        className="w-full justify-start border-gray-600 text-gray-300 hover:text-white hover:border-neon-cyan"
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleSchedule}
                  disabled={scheduleMutation.isPending}
                  className="w-full bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-purple hover:to-neon-cyan text-white font-semibold neon-glow"
                >
                  {scheduleMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Scheduling...
                    </>
                  ) : (
                    <>
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      Schedule Content
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Calendar/List View */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "calendar" | "list")}>
              <TabsContent value="calendar">
                <Card className="glass-effect border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Schedule Calendar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Calendar */}
                      <div>
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          className="glass-effect border border-gray-600 rounded-lg p-4"
                          modifiers={{
                            hasSchedule: (date) => getSchedulesForDate(date).length > 0
                          }}
                          modifiersStyles={{
                            hasSchedule: { backgroundColor: 'hsl(197, 100%, 50%, 0.2)' }
                          }}
                        />
                      </div>

                      {/* Daily Schedule */}
                      <div>
                        <h3 className="text-white font-semibold mb-4">
                          {format(selectedDate, 'MMMM dd, yyyy')}
                        </h3>
                        <div className="space-y-3 max-h-80 overflow-y-auto">
                          {getSchedulesForDate(selectedDate).map((schedule: any) => {
                            const StatusIcon = getStatusIcon(schedule.status);
                            const statusColor = getStatusColor(schedule.status);
                            const contentItem = content?.find((c: any) => c.id === schedule.contentId);
                            
                            return (
                              <div key={schedule.id} className="p-3 bg-gray-800/50 rounded-lg hover-lift">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-white font-medium">{contentItem?.title}</span>
                                  <Badge className={`bg-${statusColor}/20 text-${statusColor} border border-${statusColor}/30`}>
                                    <StatusIcon className="w-3 h-3 mr-1" />
                                    {schedule.status}
                                  </Badge>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-400">
                                  <Clock className="w-4 h-4" />
                                  {format(new Date(schedule.scheduledFor), 'HH:mm')}
                                  <span>•</span>
                                  <span>{schedule.platform}</span>
                                </div>
                              </div>
                            );
                          })}

                          {getSchedulesForDate(selectedDate).length === 0 && (
                            <div className="text-center py-8 text-gray-400">
                              <CalendarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                              <p>No content scheduled for this date</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="list">
                <Card className="glass-effect border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Scheduled Content</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {schedules?.map((schedule: any) => {
                        const StatusIcon = getStatusIcon(schedule.status);
                        const statusColor = getStatusColor(schedule.status);
                        const contentItem = content?.find((c: any) => c.id === schedule.contentId);
                        
                        return (
                          <div key={schedule.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg hover-lift">
                            <div className="flex items-center gap-4">
                              <div className={`w-10 h-10 bg-${statusColor}/20 rounded-lg flex items-center justify-center`}>
                                <StatusIcon className={`w-5 h-5 text-${statusColor}`} />
                              </div>
                              <div>
                                <h4 className="font-medium text-white">{contentItem?.title}</h4>
                                <p className="text-sm text-gray-400">
                                  {format(new Date(schedule.scheduledFor), 'MMM dd, yyyy • HH:mm')} • {schedule.platform}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge className={`bg-${statusColor}/20 text-${statusColor} border border-${statusColor}/30`}>
                                {schedule.status}
                              </Badge>
                            </div>
                          </div>
                        );
                      })}

                      {(!schedules || schedules.length === 0) && (
                        <div className="text-center py-12 text-gray-400">
                          <CalendarIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
                          <p>No scheduled content</p>
                          <p className="text-sm">Schedule your first content to get started</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
