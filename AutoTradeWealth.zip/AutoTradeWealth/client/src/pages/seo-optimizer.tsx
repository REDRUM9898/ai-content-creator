import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Target, TrendingUp, CheckCircle, AlertCircle, Loader2, Plus, X } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function SEOOptimizer() {
  const [content, setContent] = useState("");
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState("");
  const [optimizedContent, setOptimizedContent] = useState<any>(null);
  const [selectedContent, setSelectedContent] = useState<any>(null);

  const { toast } = useToast();

  const { data: contentList } = useQuery({
    queryKey: ['/api/content'],
  });

  const optimizeMutation = useMutation({
    mutationFn: (data: any) => api.ai.optimizeSEO(data),
    onSuccess: (data) => {
      setOptimizedContent(data);
      toast({
        title: "SEO Optimization Complete",
        description: "Your content has been analyzed and optimized for SEO.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Optimization Failed",
        description: error.message || "Failed to optimize content for SEO.",
        variant: "destructive",
      });
    },
  });

  const handleOptimize = () => {
    if (!content || keywords.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please provide content and at least one keyword.",
        variant: "destructive",
      });
      return;
    }

    optimizeMutation.mutate({
      content,
      keywords,
    });
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword("");
    }
  };

  const removeKeyword = (keyword: string) => {
    setKeywords(keywords.filter(k => k !== keyword));
  };

  const loadContent = (contentItem: any) => {
    setSelectedContent(contentItem);
    setContent(contentItem.body);
    setKeywords(contentItem.keywords || []);
    setOptimizedContent(null);
  };

  const getSuggestionIcon = (type: string) => {
    switch (type) {
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-400" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      default:
        return <Target className="w-4 h-4 text-blue-400" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-neon-green";
    if (score >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Good";
    if (score >= 40) return "Fair";
    return "Poor";
  };

  return (
    <div className="min-h-screen bg-dark-primary p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text">SEO Optimizer</h1>
            <p className="text-gray-400 mt-2">Optimize your content for better search engine rankings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* SEO Analysis Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="glass-effect border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Search className="w-5 h-5 text-neon-cyan" />
                  Content Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Tabs defaultValue="manual" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                    <TabsTrigger value="manual" className="text-white">Manual Input</TabsTrigger>
                    <TabsTrigger value="existing" className="text-white">Existing Content</TabsTrigger>
                  </TabsList>

                  <TabsContent value="manual" className="space-y-4 mt-6">
                    <div>
                      <Label className="text-white mb-2 block">Content to Optimize</Label>
                      <Textarea
                        placeholder="Paste your content here for SEO analysis..."
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        className="glass-effect border-gray-600 text-white bg-transparent min-h-[200px] focus:border-neon-cyan"
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="existing" className="space-y-4 mt-6">
                    <div>
                      <Label className="text-white mb-2 block">Select Content</Label>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {contentList?.map((item: any) => (
                          <div
                            key={item.id}
                            onClick={() => loadContent(item)}
                            className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                              selectedContent?.id === item.id
                                ? 'bg-neon-cyan/20 border-neon-cyan/50'
                                : 'bg-gray-800/50 border-gray-600 hover:border-gray-500'
                            }`}
                          >
                            <h4 className="font-medium text-white">{item.title}</h4>
                            <p className="text-sm text-gray-400 mt-1">
                              {item.type} • {new Date(item.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                <div>
                  <Label className="text-white mb-2 block">Target Keywords</Label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      placeholder="Add a keyword..."
                      value={newKeyword}
                      onChange={(e) => setNewKeyword(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addKeyword()}
                      className="glass-effect border-gray-600 text-white bg-transparent"
                    />
                    <Button onClick={addKeyword} size="sm" className="bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {keywords.map((keyword) => (
                      <Badge key={keyword} variant="secondary" className="bg-gray-700 text-white">
                        {keyword}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeKeyword(keyword)}
                          className="ml-1 h-auto p-0 hover:bg-transparent"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleOptimize}
                  disabled={optimizeMutation.isPending}
                  className="w-full bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-purple hover:to-neon-cyan text-white font-semibold neon-glow"
                >
                  {optimizeMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing SEO...
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 mr-2" />
                      Analyze & Optimize
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Optimized Content */}
            {optimizedContent && (
              <Card className="glass-effect border-gray-700 chart-animation">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-neon-green" />
                    Optimized Content
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="glass-effect border border-gray-600 rounded-lg p-4 text-white max-h-96 overflow-y-auto">
                    <pre className="whitespace-pre-wrap font-sans">
                      {optimizedContent.optimizedContent}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* SEO Analysis Results */}
          <div className="space-y-6">
            {optimizedContent ? (
              <>
                {/* SEO Score */}
                <Card className="glass-effect border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">SEO Score</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="mb-4">
                      <div className={`text-4xl font-bold ${getScoreColor(optimizedContent.score)}`}>
                        {optimizedContent.score}
                      </div>
                      <div className="text-sm text-gray-400 mt-1">
                        {getScoreLabel(optimizedContent.score)}
                      </div>
                    </div>
                    <Progress 
                      value={optimizedContent.score} 
                      className="w-full h-2"
                    />
                    <div className="flex justify-between text-xs text-gray-400 mt-2">
                      <span>0</span>
                      <span>100</span>
                    </div>
                  </CardContent>
                </Card>

                {/* SEO Suggestions */}
                <Card className="glass-effect border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">SEO Suggestions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {optimizedContent.suggestions?.map((suggestion: string, index: number) => (
                        <div key={index} className="flex gap-3 p-3 bg-gray-800/50 rounded-lg">
                          {getSuggestionIcon('info')}
                          <div className="flex-1">
                            <p className="text-sm text-white">{suggestion}</p>
                          </div>
                        </div>
                      ))}

                      {(!optimizedContent.suggestions || optimizedContent.suggestions.length === 0) && (
                        <div className="text-center py-8 text-gray-400">
                          <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-400" />
                          <p>Great job! No critical issues found.</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Keyword Analysis */}
                <Card className="glass-effect border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Keyword Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {keywords.map((keyword) => {
                        // Simple keyword density calculation
                        const keywordCount = content.toLowerCase().split(keyword.toLowerCase()).length - 1;
                        const wordCount = content.split(/\s+/).length;
                        const density = wordCount > 0 ? (keywordCount / wordCount) * 100 : 0;
                        
                        return (
                          <div key={keyword} className="p-3 bg-gray-800/50 rounded-lg">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-white font-medium">{keyword}</span>
                              <span className="text-sm text-gray-400">{density.toFixed(1)}%</span>
                            </div>
                            <Progress value={Math.min(density * 20, 100)} className="h-1" />
                            <div className="text-xs text-gray-400 mt-1">
                              Used {keywordCount} times
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="glass-effect border-gray-700">
                <CardContent className="text-center py-12">
                  <Search className="w-16 h-16 mx-auto mb-4 opacity-50 text-gray-400" />
                  <p className="text-gray-400">No analysis yet</p>
                  <p className="text-sm text-gray-500">Add content and keywords to start SEO analysis</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
