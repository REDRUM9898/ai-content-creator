import { create } from 'zustand';
import { Content, Campaign, Analytics, Integration, AIModel, Schedule } from '@shared/schema';

interface AppState {
  // Content state
  content: Content[];
  selectedContent: Content | null;
  contentLoading: boolean;
  
  // Analytics state
  metrics: {
    totalRevenue: number;
    monthlyRevenue: number;
    contentGenerated: number;
    totalViews: number;
    engagementRate: number;
    conversionRate: number;
    aiEfficiency: number;
    seoScore: number;
  } | null;
  
  // AI Models state
  aiModels: AIModel[];
  
  // Integration state
  integrations: Integration[];
  
  // UI state
  sidebarCollapsed: boolean;
  activeTab: string;
  notifications: Array<{
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message: string;
    timestamp: Date;
  }>;
  
  // Actions
  setContent: (content: Content[]) => void;
  setSelectedContent: (content: Content | null) => void;
  setContentLoading: (loading: boolean) => void;
  addContent: (content: Content) => void;
  updateContent: (id: number, updates: Partial<Content>) => void;
  removeContent: (id: number) => void;
  
  setMetrics: (metrics: AppState['metrics']) => void;
  setAIModels: (models: AIModel[]) => void;
  setIntegrations: (integrations: Integration[]) => void;
  
  setSidebarCollapsed: (collapsed: boolean) => void;
  setActiveTab: (tab: string) => void;
  
  addNotification: (notification: Omit<AppState['notifications'][0], 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  // Initial state
  content: [],
  selectedContent: null,
  contentLoading: false,
  metrics: null,
  aiModels: [],
  integrations: [],
  sidebarCollapsed: false,
  activeTab: 'dashboard',
  notifications: [],

  // Content actions
  setContent: (content) => set({ content }),
  setSelectedContent: (content) => set({ selectedContent: content }),
  setContentLoading: (loading) => set({ contentLoading: loading }),
  
  addContent: (content) => set((state) => ({
    content: [content, ...state.content]
  })),
  
  updateContent: (id, updates) => set((state) => ({
    content: state.content.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ),
    selectedContent: state.selectedContent?.id === id 
      ? { ...state.selectedContent, ...updates }
      : state.selectedContent
  })),
  
  removeContent: (id) => set((state) => ({
    content: state.content.filter(item => item.id !== id),
    selectedContent: state.selectedContent?.id === id ? null : state.selectedContent
  })),

  // Analytics actions
  setMetrics: (metrics) => set({ metrics }),
  
  // AI Models actions
  setAIModels: (models) => set({ aiModels: models }),
  
  // Integration actions
  setIntegrations: (integrations) => set({ integrations }),

  // UI actions
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  
  addNotification: (notification) => set((state) => ({
    notifications: [
      {
        ...notification,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date()
      },
      ...state.notifications
    ]
  })),
  
  removeNotification: (id) => set((state) => ({
    notifications: state.notifications.filter(n => n.id !== id)
  })),
  
  clearNotifications: () => set({ notifications: [] })
}));
