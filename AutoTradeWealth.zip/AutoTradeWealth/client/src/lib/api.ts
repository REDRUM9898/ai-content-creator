import { apiRequest } from './queryClient';

export const api = {
  // Content API
  content: {
    list: () => fetch('/api/content', { credentials: 'include' }).then(r => r.json()),
    create: (data: any) => apiRequest('POST', '/api/content', data).then(r => r.json()),
    update: (id: number, data: any) => apiRequest('PUT', `/api/content/${id}`, data).then(r => r.json()),
    delete: (id: number) => apiRequest('DELETE', `/api/content/${id}`).then(r => r.json()),
  },

  // AI API
  ai: {
    generate: (data: any) => apiRequest('POST', '/api/ai/generate', data).then(r => r.json()),
    optimizeSEO: (data: any) => apiRequest('POST', '/api/ai/optimize-seo', data).then(r => r.json()),
    models: () => fetch('/api/ai/models', { credentials: 'include' }).then(r => r.json()),
  },

  // Publishing API
  publish: {
    content: (data: any) => apiRequest('POST', '/api/publish', data).then(r => r.json()),
  },

  // Analytics API
  analytics: {
    metrics: () => fetch('/api/analytics/metrics', { credentials: 'include' }).then(r => r.json()),
    report: (params?: { startDate?: string; endDate?: string }) => {
      const searchParams = new URLSearchParams(params);
      return fetch(`/api/analytics/report?${searchParams}`, { credentials: 'include' }).then(r => r.json());
    },
    track: (data: any) => apiRequest('POST', '/api/analytics/track', data).then(r => r.json()),
  },

  // Campaigns API
  campaigns: {
    list: () => fetch('/api/campaigns', { credentials: 'include' }).then(r => r.json()),
    create: (data: any) => apiRequest('POST', '/api/campaigns', data).then(r => r.json()),
  },

  // Integrations API
  integrations: {
    list: () => fetch('/api/integrations', { credentials: 'include' }).then(r => r.json()),
    create: (data: any) => apiRequest('POST', '/api/integrations', data).then(r => r.json()),
    delete: (id: number) => apiRequest('DELETE', `/api/integrations/${id}`).then(r => r.json()),
  },

  // Schedules API
  schedules: {
    list: () => fetch('/api/schedules', { credentials: 'include' }).then(r => r.json()),
    create: (data: any) => apiRequest('POST', '/api/schedules', data).then(r => r.json()),
  },
};
