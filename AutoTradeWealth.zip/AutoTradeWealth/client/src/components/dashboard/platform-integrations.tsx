import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Settings, CheckCircle, AlertCircle } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface PlatformIntegrationsProps {
  integrations: any[];
}

export default function PlatformIntegrations({ integrations }: PlatformIntegrationsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createIntegrationMutation = useMutation({
    mutationFn: (data: any) => api.integrations.create(data),
    onSuccess: () => {
      toast({
        title: "Integration Added",
        description: "Platform has been successfully connected.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
    },
    onError: (error: any) => {
      toast({
        title: "Integration Failed",
        description: error.message || "Failed to connect platform.",
        variant: "destructive",
      });
    },
  });

  const platforms = [
    {
      id: "linkedin",
      name: "LinkedIn",
      icon: "🔗",
      color: "blue-500",
      description: "Professional networking"
    },
    {
      id: "twitter",
      name: "Twitter",
      icon: "🐦",
      color: "blue-400",
      description: "Social media platform"
    },
    {
      id: "medium",
      name: "Medium",
      icon: "📝",
      color: "gray-600",
      description: "Publishing platform"
    },
    {
      id: "wordpress",
      name: "WordPress",
      icon: "📰",
      color: "blue-600",
      description: "Content management"
    },
    {
      id: "mailchimp",
      name: "Mailchimp",
      icon: "📧",
      color: "yellow-500",
      description: "Email marketing"
    },
    {
      id: "youtube",
      name: "YouTube",
      icon: "📺",
      color: "red-500",
      description: "Video platform"
    }
  ];

  const getIntegrationStatus = (platformId: string) => {
    return integrations?.find(integration => integration.platform === platformId);
  };

  const handleConnect = (platformId: string) => {
    // In a real app, this would initiate OAuth flow
    createIntegrationMutation.mutate({
      platform: platformId,
      accessToken: `mock_token_${platformId}`,
      isActive: true,
      config: {}
    });
  };

  const getStatusColor = (isConnected: boolean, isActive: boolean) => {
    if (!isConnected) return "gray-400";
    return isActive ? "neon-green" : "orange-500";
  };

  const getStatusText = (isConnected: boolean, isActive: boolean) => {
    if (!isConnected) return "Not Connected";
    return isActive ? "Connected" : "Pending";
  };

  const getStatusIcon = (isConnected: boolean, isActive: boolean) => {
    if (!isConnected) return null;
    return isActive ? CheckCircle : AlertCircle;
  };

  return (
    <Card className="glass-effect border-gray-700 chart-animation">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Platform Integrations</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-neon-cyan hover:text-neon-cyan"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {platforms.map((platform) => {
            const integration = getIntegrationStatus(platform.id);
            const isConnected = !!integration;
            const isActive = integration?.isActive ?? false;
            const statusColor = getStatusColor(isConnected, isActive);
            const statusText = getStatusText(isConnected, isActive);
            const StatusIcon = getStatusIcon(isConnected, isActive);

            return (
              <div 
                key={platform.id} 
                className="text-center p-4 bg-gray-800/50 rounded-lg hover-lift cursor-pointer group"
                onClick={() => !isConnected && handleConnect(platform.id)}
              >
                <div className={`w-12 h-12 bg-${platform.color}/20 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform`}>
                  <span className="text-2xl">{platform.icon}</span>
                </div>
                <p className="text-xs font-medium text-white mb-1">{platform.name}</p>
                <div className="flex items-center justify-center gap-1">
                  {StatusIcon && <StatusIcon className={`w-3 h-3 text-${statusColor}`} />}
                  <p className={`text-xs text-${statusColor}`}>
                    {statusText}
                  </p>
                </div>

                {!isConnected && (
                  <Button 
                    size="sm"
                    className="mt-2 w-full bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30 hover:bg-neon-cyan/30 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleConnect(platform.id);
                    }}
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    Connect
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        {/* Connected Platforms Summary */}
        <div className="mt-6 pt-4 border-t border-gray-600">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Connected Platforms</span>
            <span className="text-neon-green font-medium">
              {integrations?.filter(i => i.isActive).length || 0} / {platforms.length}
            </span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
            <div
              className="bg-gradient-to-r from-neon-cyan to-neon-green h-2 rounded-full transition-all duration-500"
              style={{ 
                width: `${((integrations?.filter(i => i.isActive).length || 0) / platforms.length) * 100}%` 
              }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
