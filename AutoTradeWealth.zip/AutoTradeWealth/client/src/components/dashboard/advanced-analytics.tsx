import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

interface AdvancedAnalyticsProps {
  metrics: any;
}

export default function AdvancedAnalytics({ metrics }: AdvancedAnalyticsProps) {
  const analyticsCards = [
    {
      title: "SEO Performance",
      value: `${metrics?.seoScore?.toFixed(1)}%` || '0%',
      description: "Average ranking improvement",
      color: "neon-green",
    },
    {
      title: "Engagement Rate",
      value: `${metrics?.engagementRate?.toFixed(1)}%` || '0%',
      description: "Across all platforms",
      color: "neon-cyan",
    },
    {
      title: "Conversion Rate",
      value: `${metrics?.conversionRate?.toFixed(1)}%` || '0%',
      description: "Content to sales conversion",
      color: "neon-purple",
    },
  ];

  return (
    <Card className="glass-effect border-gray-700 chart-animation">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Advanced Performance Analytics</CardTitle>
          <div className="flex items-center space-x-2">
            <Button 
              size="sm" 
              className="bg-neon-purple/20 text-neon-purple border border-neon-purple/30"
            >
              Real-time
            </Button>
            <Button variant="ghost" size="sm" className="glass-effect text-gray-400 border border-gray-600 hover:border-neon-purple hover:text-neon-purple">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {analyticsCards.map((card, index) => (
            <div key={card.title} className="text-center chart-animation" style={{ animationDelay: `${index * 0.1}s` }}>
              <div className="w-full h-32 bg-gray-800/50 rounded-lg mb-4 flex items-center justify-center">
                <div className="text-center">
                  <div className={`w-16 h-16 bg-${card.color}/20 rounded-lg mx-auto mb-2 flex items-center justify-center`}>
                    <span className={`text-2xl font-bold text-${card.color}`}>
                      {card.value.replace('%', '')}
                    </span>
                  </div>
                  <span className={`text-xs text-${card.color}`}>%</span>
                </div>
              </div>
              <h4 className="font-semibold mb-2 text-white">{card.title}</h4>
              <p className={`text-2xl font-bold text-${card.color} mb-1`}>{card.value}</p>
              <p className="text-xs text-gray-400">{card.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
