import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Brain, Cpu, Gem } from "lucide-react";

interface AIModelsPerformanceProps {
  models: any[];
}

export default function AIModelsPerformance({ models }: AIModelsPerformanceProps) {
  const modelIcons = {
    'gpt-4': Brain,
    'claude': Cpu,
    'gemini': Gem
  };

  const modelColors = {
    'gpt-4': 'neon-green',
    'claude': 'neon-cyan',
    'gemini': 'neon-purple'
  };

  return (
    <Card className="glass-effect border-gray-700 chart-animation">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">AI Models Performance</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {models?.map((model) => {
          const IconComponent = modelIcons[model.model as keyof typeof modelIcons] || Brain;
          const color = modelColors[model.model as keyof typeof modelColors] || 'neon-green';
          const successRate = parseFloat(model.successRate || '0');
          const qualityScore = parseFloat(model.qualityScore || '0');

          return (
            <div key={model.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg hover-lift">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 bg-${color}/20 rounded-lg flex items-center justify-center`}>
                  <IconComponent className={`w-4 h-4 text-${color}`} />
                </div>
                <div>
                  <p className="font-medium text-sm text-white">{model.name}</p>
                  <p className="text-xs text-gray-400">Content Quality: {qualityScore}/10</p>
                </div>
              </div>
              <div className="text-right min-w-[80px]">
                <p className={`text-sm font-semibold text-${color}`}>{successRate.toFixed(0)}%</p>
                <p className="text-xs text-gray-400">Success Rate</p>
                <Progress 
                  value={successRate} 
                  className="w-16 h-1 mt-1"
                />
              </div>
            </div>
          );
        })}

        {(!models || models.length === 0) && (
          <div className="text-center py-8 text-gray-400">
            <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No AI models configured</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
