import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, ExternalLink, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useAppStore } from "@/lib/store";

export default function QuickGeneration() {
  const [contentType, setContentType] = useState("");
  const [topic, setTopic] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["linkedin"]);
  const { toast } = useToast();
  const { addContent } = useAppStore();
  const queryClient = useQueryClient();

  const platforms = [
    { id: "linkedin", name: "LinkedIn", color: "neon-cyan" },
    { id: "twitter", name: "Twitter", color: "gray" },
    { id: "medium", name: "Medium", color: "gray" },
    { id: "youtube", name: "YouTube", color: "gray" },
  ];

  const generateMutation = useMutation({
    mutationFn: (data: any) => api.ai.generate(data),
    onSuccess: (data) => {
      toast({
        title: "Content Generated Successfully",
        description: "Your AI-generated content is ready for review and publishing.",
      });
      addContent(data);
      queryClient.invalidateQueries({ queryKey: ['/api/content'] });
      setTopic("");
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!contentType || !topic) {
      toast({
        title: "Missing Information",
        description: "Please select content type and enter a topic.",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      prompt: topic,
      contentType,
      model: 'gpt-4',
      platforms: selectedPlatforms,
    });
  };

  const togglePlatform = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform) 
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  return (
    <Card className="glass-effect border-gray-700 chart-animation">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Quick Content Generation</CardTitle>
          <Button variant="ghost" size="sm" className="text-neon-cyan hover:text-neon-cyan">
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-sm font-medium text-white mb-2 block">Content Type</Label>
          <Select value={contentType} onValueChange={setContentType}>
            <SelectTrigger className="glass-effect border-gray-600 text-white bg-transparent">
              <SelectValue placeholder="Select content type" />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              <SelectItem value="blog">Blog Post</SelectItem>
              <SelectItem value="social">Social Media</SelectItem>
              <SelectItem value="email">Email Campaign</SelectItem>
              <SelectItem value="ad">Advertisement</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-sm font-medium text-white mb-2 block">Topic/Keywords</Label>
          <Input
            placeholder="Enter your topic or keywords..."
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="glass-effect border-gray-600 text-white bg-transparent focus:border-neon-cyan"
          />
        </div>

        <div>
          <Label className="text-sm font-medium text-white mb-2 block">Target Platform</Label>
          <div className="flex flex-wrap gap-2">
            {platforms.map(platform => (
              <Button
                key={platform.id}
                size="sm"
                variant={selectedPlatforms.includes(platform.id) ? "default" : "outline"}
                onClick={() => togglePlatform(platform.id)}
                className={
                  selectedPlatforms.includes(platform.id)
                    ? "bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30"
                    : "bg-gray-800 text-gray-400 border border-gray-600 hover:border-neon-cyan hover:text-neon-cyan"
                }
              >
                {platform.name}
              </Button>
            ))}
          </div>
        </div>

        <Button 
          onClick={handleGenerate}
          disabled={generateMutation.isPending}
          className="w-full bg-gradient-to-r from-neon-cyan to-neon-purple hover:from-neon-purple hover:to-neon-cyan text-white font-semibold neon-glow"
        >
          {generateMutation.isPending ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4 mr-2" />
              Generate Content
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
