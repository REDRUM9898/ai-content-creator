import { DollarSign, FileText, Eye, Bot, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface MetricsCardsProps {
  metrics: any;
  loading: boolean;
}

export default function MetricsCards({ metrics, loading }: MetricsCardsProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="glass-effect border-gray-700">
            <CardContent className="p-6">
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Monthly Revenue",
      value: `$${metrics?.monthlyRevenue?.toLocaleString() || '0'}`,
      change: "+23.5%",
      changeText: "vs last month",
      icon: DollarSign,
      color: "neon-green",
      glowClass: "neon-glow-green"
    },
    {
      title: "Content Generated",
      value: metrics?.contentGenerated?.toLocaleString() || '0',
      change: "+18.2%",
      changeText: "this week",
      icon: FileText,
      color: "neon-cyan",
      glowClass: "neon-glow"
    },
    {
      title: "Total Views",
      value: `${(metrics?.totalViews / 1000).toFixed(0)}K` || '0K',
      change: "+31.4%",
      changeText: "engagement up",
      icon: Eye,
      color: "neon-purple",
      glowClass: "neon-glow-purple"
    },
    {
      title: "AI Efficiency",
      value: `${metrics?.aiEfficiency?.toFixed(1)}%` || '0%',
      change: "+5.1%",
      changeText: "optimization",
      icon: Bot,
      color: "orange-500",
      glowClass: ""
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card 
            key={card.title} 
            className={`glass-effect border-${card.color}/30 chart-animation hover-lift ${card.glowClass}`}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 bg-${card.color}/20 rounded-lg flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 text-${card.color}`} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">{card.title}</p>
                    <p className={`text-2xl font-bold text-${card.color}`}>{card.value}</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <TrendingUp className={`w-4 h-4 text-${card.color}`} />
                <span className={`text-${card.color}`}>{card.change}</span>
                <span className="text-gray-400">{card.changeText}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
