import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts";
import { cn } from "@/lib/utils";

interface RevenueChartProps {
  metrics: any;
  className?: string;
}

export default function RevenueChart({ metrics, className }: RevenueChartProps) {
  // Mock data for demonstration - in real app this would come from metrics
  const revenueData = [
    { date: "Jan", revenue: 12000, views: 45000 },
    { date: "Feb", revenue: 15000, views: 52000 },
    { date: "Mar", revenue: 18000, views: 61000 },
    { date: "Apr", revenue: 22000, views: 70000 },
    { date: "May", revenue: 24589, views: 85000 },
  ];

  return (
    <Card className={cn("glass-effect border-gray-700 chart-animation", className)}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Revenue Analytics</CardTitle>
          <div className="flex items-center space-x-2">
            <Button 
              size="sm" 
              className="bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30 hover:bg-neon-cyan/30"
            >
              7D
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              30D
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              90D
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="date" 
                stroke="#9CA3AF"
                fontSize={12}
              />
              <YAxis 
                stroke="#9CA3AF"
                fontSize={12}
                tickFormatter={(value) => `$${value.toLocaleString()}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#111111',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#fff'
                }}
                formatter={(value: any, name: string) => [
                  name === 'revenue' ? `$${value.toLocaleString()}` : value.toLocaleString(),
                  name === 'revenue' ? 'Revenue' : 'Views'
                ]}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="hsl(197, 100%, 50%)" 
                strokeWidth={3}
                dot={{ fill: 'hsl(197, 100%, 50%)', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: 'hsl(197, 100%, 50%)', strokeWidth: 2, fill: '#fff' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
