import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Clock, Share, History } from "lucide-react";
import { api } from "@/lib/api";
import { formatDistanceToNow } from "date-fns";

export default function RecentActivity() {
  const { data: content } = useQuery({
    queryKey: ['/api/content'],
  });

  // Get recent content (last 5 items)
  const recentContent = content?.slice(0, 5) || [];

  const getActivityIcon = (status: string) => {
    switch (status) {
      case 'published':
        return { icon: Check, color: 'neon-green' };
      case 'generated':
        return { icon: Clock, color: 'orange-500' };
      case 'scheduled':
        return { icon: Share, color: 'neon-cyan' };
      default:
        return { icon: Clock, color: 'gray-400' };
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'published':
        return 'Published';
      case 'generated':
        return 'Generated';
      case 'scheduled':
        return 'Scheduled';
      default:
        return 'Draft';
    }
  };

  return (
    <Card className="glass-effect border-gray-700 chart-animation">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Recent Content Activity</CardTitle>
          <Button variant="ghost" size="sm" className="text-neon-purple hover:text-neon-purple">
            <History className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {recentContent.map((item: any) => {
          const activity = getActivityIcon(item.status);
          const Icon = activity.icon;
          
          return (
            <div key={item.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg hover-lift">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 bg-${activity.color}/20 rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-4 h-4 text-${activity.color}`} />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{item.title}</p>
                  <p className="text-xs text-gray-400">
                    {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-xs text-${activity.color}`}>{getStatusText(item.status)}</p>
                <p className="text-xs text-gray-400">{item.platforms?.[0] || 'Multi-platform'}</p>
              </div>
            </div>
          );
        })}

        {recentContent.length === 0 && (
          <div className="text-center py-8 text-gray-400">
            <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No recent activity</p>
            <p className="text-sm">Generate some content to see activity here</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
